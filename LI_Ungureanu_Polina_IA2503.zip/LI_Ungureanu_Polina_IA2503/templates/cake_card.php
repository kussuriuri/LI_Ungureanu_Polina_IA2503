<?php

//карточка торта; переменная $cake задаётся в цикле шаблона, который подключает этот файл

/**
 * @var array $cake
 */

$imageUrl = getCakeImageUrl($cake['image']);
?>

<article class="product">
    <a class="product-media" href="cake.php?id=<?= h((string) $cake['id']) ?>">
        <?php if ($imageUrl !== null): ?>
            <img class="cake-img" src="<?= h($imageUrl) ?>" alt="<?= h($cake['title']) ?>">
        <?php else: ?>
            <div class="cake-img placeholder">🍰</div>
        <?php endif; ?>

        <?php if (!$cake['is_available']): ?>
            <span class="media-badge">Нет в наличии</span>
        <?php endif; ?>
    </a>

    <div class="product-info">
        <h3><a href="cake.php?id=<?= h((string) $cake['id']) ?>"><?= h($cake['title']) ?></a></h3>

        <p class="product-flavor"><?= h($cake['flavor']) ?></p>

        <div class="product-bottom">
            <span class="price"><?= h((string) $cake['price']) ?> лей</span>

            <?php if ($cake['is_available']): ?>
                <a class="pill" href="order.php?cake_id=<?= h((string) $cake['id']) ?>">Заказать</a>
            <?php endif; ?>
        </div>
    </div>
</article>