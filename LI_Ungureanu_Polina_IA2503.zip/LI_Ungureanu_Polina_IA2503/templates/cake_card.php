<?php

//карточка торта; переменная $cake задаётся в цикле шаблона, который подключает этот файл; - главная страница и каталог

/**
 * @var array $cake
 */

$imageUrl = getCakeImageUrl($cake['image']);
?>

<article class="product">
    <a class="product-media" href="cake.php?id=<?= h((string) $cake['id']) ?>"><!--при нажатии на карточку браузер перейдёт на страницу торта с идентификатором 5-->
        <?php if ($imageUrl !== null): ?>
            <img class="cake-img" src="<?= h($imageUrl) ?>" alt="<?= h($cake['title']) ?>"><!--alt = альтернатив текст при отсутсвии картинки-->
        <?php endif; ?>

        <?php if (!$cake['is_available']): ?>
            <span class="media-badge">Нет в наличии</span><!--стоковая отметка-->
        <?php endif; ?>
    </a>

    <div class="product-info">
        <h3><a href="cake.php?id=<?= h((string) $cake['id']) ?>"><?= h($cake['title']) ?></a></h3><!--название торта = ссылка на его страницу-->

        <p class="product-flavor"><?= h($cake['flavor']) ?></p><!--абзац-->

        <div class="product-bottom">
            <span class="price"><?= h((string) $cake['price']) ?> лей</span>

            <?php if ($cake['is_available']): ?>
                <a class="pill" href="order.php?cake_id=<?= h((string) $cake['id']) ?>">Заказать</a><!--появляется ссылка кнопки-->
            <?php endif; ?>
        </div>
    </div>
</article>