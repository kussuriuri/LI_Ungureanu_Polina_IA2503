<?php

//страница одного торта

/**
 * @var array $cake
 */

$imageUrl = getCakeImageUrl($cake['image']);
?>

<a class="back-link" href="catalog.php">← Назад в каталог</a>

<article class="cake-page">

    <div>
        <?php if ($imageUrl !== null): ?>
            <img class="cake-img large" src="<?= h($imageUrl) ?>" alt="<?= h($cake['title']) ?>">
        <?php else: ?>
            <div class="cake-img large placeholder"></div>
        <?php endif; ?>
    </div>

    <div class="cake-info">
        <span class="chip"><?= h($cake['flavor']) ?></span>

        <h1><?= h($cake['title']) ?></h1>

        <p class="cake-desc"><?= h($cake['description']) ?></p>

        <p class="cake-price"><?= h((string) $cake['price']) ?> лей</p>

        <?php if ($cake['is_available']): ?>
            <a class="btn" href="order.php?cake_id=<?= h((string) $cake['id']) ?>">Заказать этот торт</a>
        <?php else: ?>
            <span class="badge">Нет в наличии</span>
        <?php endif; ?>

        <p class="meta">Добавлен: <?= h(formatDate($cake['created_at'])) ?></p>
    </div>

</article>