<?php

//главная страница

/**
 * @var array|null $currentUser
 * @var array $newCakes
 * @var array $fillings
 */
?>

<section class="hero">
    <div class="hero-text">
        <p class="hero-tag">Бенто-торты на заказ</p>

        <h1>Маленький торт — большое настроение</h1>

        <p class="hero-lead">
            Торты на 1-2 порции в коробочке с вашей надписью и декором.
            Выберите вкус, начинку и дату, остальное мы возьмём на себя.
        </p>

        <div class="hero-actions">
            <a class="btn" href="catalog.php">Смотреть каталог</a>

            <?php if ($currentUser === null): ?>
                <a class="btn btn-ghost" href="register.php">Создать аккаунт</a>
            <?php else: ?>
                <a class="btn btn-ghost" href="order.php">Заказать торт</a>
            <?php endif; ?>
        </div>

        <?php if ($currentUser === null): ?>
            <p class="hero-note">Уже есть аккаунт? <a href="login.php">Войти</a></p>
        <?php endif; ?>
    </div>
</section>


<h2>Как это работает</h2>

<div class="steps">
    <div class="step">
        <div class="step-num">1</div>
        <h3>Выберите торт</h3>
        <p>Посмотрите каталог и найдите вкус по душе.</p>
    </div>

    <div class="step">
        <div class="step-num">2</div>
        <h3>Добавьте детали</h3>
        <p>Начинка, декор, надпись и подарочная упаковка.</p>
    </div>

    <div class="step">
        <div class="step-num">3</div>
        <h3>Заберите в срок</h3>
        <p>Выберите дату, мы подготовим торт к этому дню.</p>
    </div>
</div>


<div class="section-head">
    <h2>Новинки</h2>
    <a href="catalog.php">Весь каталог →</a>
</div>

<?php if ($newCakes === []): ?>
    <p>Новинок пока нет.</p>
<?php else: ?>
    <div class="products">
        <?php foreach ($newCakes as $cake): ?>
            <?php require __DIR__ . '/cake_card.php'; ?>
        <?php endforeach; ?>
    </div>
<?php endif; ?>


<h2>Начинки</h2>

<?php if ($fillings === []): ?>
    <p>Начинок пока нет.</p>
<?php else: ?>
    <div class="fillings">
        <?php foreach ($fillings as $filling): ?>
            <div class="filling">
                <h3><?= h($filling['name']) ?></h3>

                <p><?= h($filling['description']) ?></p>

                <span class="badge">
                    <?= (int) $filling['extra_price'] > 0
                        ? '+' . h((string) $filling['extra_price']) . ' лей'
                        : 'Без доплаты' ?>
                </span>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>