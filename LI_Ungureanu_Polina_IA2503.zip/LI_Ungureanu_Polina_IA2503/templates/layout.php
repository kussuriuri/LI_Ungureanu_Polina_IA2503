<?php
//общий макет сайта

/**
 * @var string $title
 * @var array|null $currentUser
 * @var array $parts
 */
?>

<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($title) ?></title>

    <style>
        :root {/*корневой эл-т html док-а*/
            --blue: #afcbfa;/*cозд перем со знач цвета*/
            --blue-soft: #eef4ff;
            --blue-line: #d3e2fb;
            --brown: #522b1b;
            --brown-hover: #6b3a26;
            --muted: rgba(82, 43, 27, 0.65);/*цвет с прозрачностью*/
        }

        * {/*универс селектор*/
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Inter, -apple-system, "Segoe UI", Roboto, Arial, sans-serif;
            background: #fff;
            color: var(--brown);
            line-height: 1.55;
        }

        a {/*ссылки - коричн*/
            color: var(--brown);
        }

        h1, h2, h3 {/*заголовки*/
            font-family: Georgia, "Times New Roman", serif;
            color: var(--brown);
            line-height: 1.2;
        }

        h2 {
            margin: 44px 0 18px;
            font-size: 28px;
        }

        h3 {
            margin: 0 0 8px;
            font-size: 19px;
        }

        .site-header {/*селектор класса. Точка перед названием означает, что правило применяется к HTML-элементу с class="site-header*/
            position: sticky;
            top: 0;
            z-index: 10;
            background: rgba(255, 255, 255, 0.92);
            backdrop-filter: blur(8px);
            border-bottom: 1px solid var(--blue-line);
        }

        .nav {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px 24px;
            max-width: 1180px;
            margin: 0 auto;
            padding: 14px 24px;
        }

        .brand {
            font-family: Georgia, "Times New Roman", serif;
            font-size: 21px;
            font-weight: bold;
            text-decoration: none;
        }

        .nav a:not(.brand) {
            padding: 4px 0;
            border-bottom: 2px solid transparent;
            font-weight: 500;
            text-decoration: none;
        }

        .nav a:not(.brand):hover {
            border-bottom-color: var(--blue);
        }

        .user-name {
            margin-left: auto;
            font-size: 14px;
            color: var(--muted);
        }

        .nav form {
            margin: 0;
        }

        .container {
            max-width: 1180px;
            margin: 0 auto;
            padding: 32px 24px 60px;
        }

        .container > h2:first-child {
            margin-top: 0;
        }

        .site-footer {
            padding: 28px 24px;
            border-top: 1px solid var(--blue-line);
            text-align: center;
            font-size: 14px;
            color: var(--muted);
        }

        button, .btn {
            display: inline-block;
            padding: 11px 22px;
            border: 1.5px solid var(--brown);
            border-radius: 999px;
            background: var(--brown);
            color: #fff;
            font: inherit;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: background 0.2s, color 0.2s;
        }

        button:hover, .btn:hover {
            background: var(--brown-hover);
            border-color: var(--brown-hover);
        }

        .btn-ghost {
            background: transparent;
            color: var(--brown);
        }

        .btn-ghost:hover {
            background: var(--brown);
            color: #fff;
        }

        .btn-sm {
            padding: 7px 16px;
            font-size: 14px;
        }
        /*формы*/
        label {
            display: block;
            font-weight: 600;
            font-size: 14px;
        }

        input:not([type="checkbox"]):not([type="radio"]),/*поля input - не чекбоксы*/
        select,
        textarea {
            display: block;
            width: 100%;
            margin: 6px 0 18px;
            padding: 11px 14px;
            border: 1.5px solid var(--blue-line);
            border-radius: 12px;
            background: #fff;
            color: var(--brown);
            font: inherit;
        }

        textarea {
            min-height: 110px;
            resize: vertical;
        }

        input:focus, select:focus, textarea:focus {/*сраб когда польз выбрал поле*/
            outline: none;
            border-color: var(--brown);
            box-shadow: 0 0 0 3px var(--blue);
        }

        input[type="checkbox"], input[type="radio"] {
            width: 18px;
            height: 18px;
            margin: 0;
            accent-color: var(--brown);
        }

        .option {/*флажок и подпись рядом друг с другом*/
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 10px;
            font-size: 16px;
            font-weight: 400;
            cursor: pointer;
        }

        /* формы входа, регистрации, заказа и админские - в виде карточки */
        .container > form:not(.filters),
        .auth form {
            max-width: 560px;
            padding: 28px;
            border-radius: 22px;
            background: var(--blue-soft);
        }

        /* страницы входа и регистрации - по центру */
        .auth {
            max-width: 460px;
            margin: 24px auto 0;
        }

        .auth h2 {
            margin-top: 0;
            text-align: center;
        }

        .auth form {
            max-width: none;
        }

        .auth .success {
            max-width: none;
        }

        .auth > p {
            text-align: center;
        }

        .auth button[type="submit"] {
            width: 100%;
        }

        .errors {
            margin: -10px 0 16px;
            padding: 0;
            list-style: none;
            color: #c0392b;
            font-size: 13.5px;
        }

        .success {
            max-width: 560px;
            padding: 12px 16px;
            border-left: 4px solid var(--blue);
            border-radius: 10px;
            background: var(--blue-soft);
        }

        .error-message {
            padding: 12px 16px;
            border-left: 4px solid #d64545;
            border-radius: 10px;
            background: #fdecec;
            color: #8a1c21;
        }

        /*форма поиска*/

        .filters {
            margin: 0 0 28px;
            padding: 22px 24px;
            border-radius: 22px;
            background: var(--blue-soft);
        }

        .filters-grid {
            display: grid;
            grid-template-columns: 2fr 1fr 1.3fr;
            gap: 18px 22px;
            align-items: start;
        }

        .filters .field label {
            margin-bottom: 6px;
            font-size: 12px;
            letter-spacing: 0.06em;
            text-transform: uppercase;
            color: var(--muted);
        }

        .filters .field input:not([type="checkbox"]),
        .filters .field select {
            margin: 0;
        }

        .filters .errors {
            margin: 6px 0 0;
        }

        .input-icon {
            position: relative;
        }

        .input-icon span {
            position: absolute;
            top: 50%;
            left: 14px;
            transform: translateY(-50%);
            pointer-events: none;
        }

        .filters .input-icon input {
            padding-left: 42px;
        }

        .range {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .range input {
            min-width: 0;
        }

        .range span {
            color: var(--muted);
        }

        .filters-bottom {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            margin-top: 20px;
        }

        .filters-actions {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .switch-label {
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 0;
            font-size: 15px;
            font-weight: 500;
            cursor: pointer;
        }

        input[type="checkbox"].switch {
            appearance: none;
            -webkit-appearance: none;
            position: relative;
            flex-shrink: 0;
            width: 46px;
            height: 26px;
            border-radius: 999px;
            background: var(--blue-line);
            cursor: pointer;
            transition: background 0.2s;
        }

        input[type="checkbox"].switch::after {
            content: "";
            position: absolute;
            top: 3px;
            left: 3px;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: #fff;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.25);
            transition: transform 0.2s;
        }

        input[type="checkbox"].switch:checked {
            background: var(--brown);
        }

        input[type="checkbox"].switch:checked::after {
            transform: translateX(20px);
        }

        .result-info {
            margin: 0 0 20px;
            color: var(--muted);
        }

        .empty {
            padding: 48px 20px;
            border-radius: 22px;
            background: var(--blue-soft);
            text-align: center;
        }

        /* карточки тортов */

        .products {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 36px 26px;
        }

        .product-media {
            position: relative;
            display: block;
            overflow: hidden;
            border-radius: 18px;
            background: var(--blue-soft);
        }

        .cake-img {
            display: block;
            width: 100%;
            aspect-ratio: 4 / 3;
            object-fit: cover;
        }

        .cake-img[hidden] {
            display: none;
        }

        .cake-img.placeholder {
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--blue-soft);
            font-size: 56px;
        }

        .product-media .cake-img {
            transition: transform 0.4s;
        }

        .product-media:hover .cake-img {
            transform: scale(1.05);
        }

        .cake-img.large {
            max-width: 560px;
            margin-bottom: 22px;
            border-radius: 22px;
        }

        .media-badge {
            position: absolute;
            top: 12px;
            left: 12px;
            padding: 4px 12px;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.94);
            font-size: 13px;
            font-weight: 600;
        }

        .product-info {
            padding: 14px 2px 0;
        }

        .product-info h3 {
            margin-bottom: 2px;
        }

        .product-info h3 a {
            text-decoration: none;
        }

        .product-flavor {
            margin: 0 0 12px;
            font-size: 14px;
            color: var(--muted);
        }

        .product-flavor::first-letter,
        .chip::first-letter {
            text-transform: uppercase;
        }

        .product-bottom {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
        }

        .price {
            font-size: 18px;
            font-weight: 700;
        }

        .pill {
            padding: 7px 16px;
            border-radius: 999px;
            background: var(--blue);
            font-size: 14px;
            font-weight: 600;
            text-decoration: none;
            transition: background 0.2s, color 0.2s;
        }

        .pill:hover {
            background: var(--brown);
            color: #fff;
        }

        .meta {
            font-size: 14px;
            color: var(--muted);
        }

        .badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 999px;
            background: var(--blue);
            font-size: 13px;
            font-weight: 600;
        }

        .chip {
            display: inline-block;
            padding: 4px 14px;
            border-radius: 999px;
            background: var(--blue);
            font-size: 14px;
            font-weight: 600;
        }

        /* ---------- страница торта ---------- */

        .back-link {
            display: inline-block;
            margin-bottom: 24px;
            text-decoration: none;
            font-weight: 500;
        }

        .cake-page {
            display: grid;
            grid-template-columns: minmax(0, 1.1fr) minmax(0, 1fr);
            gap: 48px;
            align-items: start;
        }

        .cake-page .cake-img.large {
            max-width: none;
            margin-bottom: 0;
        }

        .cake-info h1 {
            margin: 14px 0;
            font-size: 40px;
        }

        .cake-desc {
            margin: 0 0 20px;
            font-size: 17px;
        }

        .cake-price {
            margin: 0 0 24px;
            font-size: 32px;
            font-weight: 700;
        }

        .cake-thumb {
            width: 64px;
            height: 64px;
            margin-right: 12px;
            border-radius: 12px;
            object-fit: cover;
            vertical-align: middle;
        }

        /*главная*/

        .hero {
    position: relative;
    overflow: hidden;
    padding: 60px 52px;
    border-radius: 28px;
    background: linear-gradient(135deg, var(--blue) 0%, #dbe7fd 100%);
    text-align: center;
}

.hero::after {
    content: none;
}

.hero-text {
    position: relative;
    z-index: 1;
    max-width: 800px;
    margin: 0 auto;
}

.hero-tag {
    margin: 0 0 10px;
    font-size: 13px;
    font-weight: 700;
    letter-spacing: 0.08em;
    text-transform: uppercase;
}

.hero h1 {
    margin: 0 0 16px;
    font-size: 46px;
}

.hero-lead {
    margin: 0 0 26px;
    font-size: 18px;
}

.hero-actions {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 12px;
}

.hero-note {
    margin: 18px 0 0;
    font-size: 14px;
}

        .hero-tag {
            margin: 0 0 10px;
            font-size: 13px;
            font-weight: 700;
            letter-spacing: 0.08em;
            text-transform: uppercase;
        }

        .hero h1 {
            margin: 0 0 16px;
            font-size: 46px;
        }

        .hero-lead {
            margin: 0 0 26px;
            font-size: 18px;
        }

        .hero-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
        }

        .hero-note {
            margin: 18px 0 0;
            font-size: 14px;
        }

        .section-head {
            display: flex;
            align-items: baseline;
            justify-content: space-between;
            gap: 16px;
        }

        .section-head a {
            font-weight: 600;
            text-decoration: none;
        }

        .steps {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 22px;
        }

        .step-num {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            margin-bottom: 12px;
            border-radius: 50%;
            background: var(--blue);
            font-weight: 700;
        }

        .step p, .filling p {
            margin: 0;
            color: var(--muted);
        }

        .fillings, .cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
            gap: 20px;
        }

        .card, .filling {
            padding: 22px;
            border-radius: 18px;
            background: var(--blue-soft);
        }

        .card p {
            margin: 0 0 16px;
            color: var(--muted);
        }

        .filling .badge {
            margin-top: 12px;
        }

        /* таблицы (админка, мои заказы) */

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        th, td {
            padding: 14px 12px;
            border-bottom: 1px solid var(--blue-line);
            text-align: left;
            vertical-align: top;
        }

        th {
            background: var(--blue-soft);
            font-size: 13px;
            letter-spacing: 0.04em;
            text-transform: uppercase;
        }

        td form {
            display: inline-block;
            margin: 0 4px 4px 0;
        }

        td form select, td form button {
            display: inline-block;
            width: auto;
            margin: 0 4px 0 0;
            padding: 7px 12px;
            font-size: 14px;
        }
    </style>
</head>

<body>

<header class="site-header">
    <nav class="nav"><!--тег для навигации-->
        <a class="brand" href="index.php">Bento Cake Studio</a><!--ссылка на главную стр если нажать на эту надпись-->
        <a href="catalog.php">Каталог</a>

        <?php if ($currentUser === null): ?>
            <a href="login.php">Войти</a>
            <a href="register.php">Регистрация</a>
        <?php else: ?>
            <a href="order.php">Заказать торт</a>
            <a href="my_orders.php">Мои заказы</a>

            <?php if ($currentUser['role'] === 'admin'): ?>
                <a href="admin.php">Админ-панель</a>
            <?php endif; ?>

            <span class="user-name"><!--строч содержимое-->
                <?= h($currentUser['name']) ?><!--выв имени пользователя безопас обраб-->
                (<?= $currentUser['role'] === 'admin' ? 'администратор' : 'клиент' ?>)
            </span>

            <form action="logout.php" method="post">
                <input type="hidden" name="action" value="logout">
                <button type="submit" class="btn-ghost btn-sm">Выйти</button>
            </form>
        <?php endif; ?>
    </nav>
</header>

<main class="container">
    <?php foreach ($parts as $part): ?>
        <?php require __DIR__ . '/' . $part; ?>
    <?php endforeach; ?>
</main>

<footer class="site-footer">
    <?= date('Y') ?> Bento Cake Studio
</footer>

</body>
</html>