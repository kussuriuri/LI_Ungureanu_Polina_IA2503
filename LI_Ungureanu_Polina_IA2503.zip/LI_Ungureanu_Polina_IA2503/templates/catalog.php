<?php

//каталог тортов и форма поиска

/**
 * @var array $cakes
 * @var array $errors
 * @var array $data
 * @var array $flavors
 * @var bool $isSearch
 */
?>

<h2>Каталог тортов</h2>

<form action="catalog.php" method="get" class="filters"><!-- куда отпр данные формы-->

    <div class="filters-grid">

        <div class="field">
            <label for="q">Поиск по названию</label><!-- связ подпись с полем у кот id = q-->

            <div class="input-icon">
                <!-- поле ввода-->
                 <!--value = значение, которое уже должно отображаться в поле - польз должен видеть введенные данные в поле-->
                <input
                    type="text"
                    name="q"
                    id="q"
                    maxlength="50"
                    placeholder="Например, шоколадный"
                    value="<?= h($data['q']) ?>"
                >
            </div>

            <?php getErrors($errors, 'q'); ?>
        </div>


        <div class="field">
            <label for="flavor">Вкус</label>

            <select name="flavor" id="flavor">
                <option value="">Любой</option>

                <?php foreach ($flavors as $flavor): ?>
                    <?php $flavorName = mb_strtoupper(mb_substr($flavor, 0, 1, 'UTF-8'), 'UTF-8') . mb_substr($flavor, 1, null, 'UTF-8'); ?>
                    <!--первая буква вкуса = заглав-->
                    <option
                        value="<?= h($flavor) ?>"
                        <?= $flavor === $data['flavor'] ? 'selected' : '' ?>
                    >
                        <?= h($flavorName) ?><!--выводимый текст при выводе-->
                    </option>
                <?php endforeach; ?>
            </select>

            <?php getErrors($errors, 'flavor'); ?>
        </div>


        <div class="field">
            <label for="price_min">Цена, лей</label>

            <div class="range">
                <input
                    type="number"
                    name="price_min"
                    id="price_min"
                    min="0"
                    max="1000000"
                    placeholder="от"
                    value="<?= h($data['price_min']) ?>"
                >

                <span>—</span>

                <input
                    type="number"
                    name="price_max"
                    id="price_max"
                    min="0"
                    max="1000000"
                    placeholder="до"
                    aria-label="Цена до, лей"
                    value="<?= h($data['price_max']) ?>"
                >
            </div>

            <?php getErrors($errors, 'price_min'); ?>
            <?php getErrors($errors, 'price_max'); ?>
        </div>

    </div>

    <div class="filters-bottom">

        <div>
            <label class="switch-label">
                <input
                    type="checkbox"
                    class="switch"
                    name="only_available"
                    value="1"
                    <?= $data['only_available'] ? 'checked' : '' ?>
                >
                Только в наличии
            </label>

            <?php getErrors($errors, 'only_available'); ?>
        </div>

        <div class="filters-actions">
            <button type="submit">Найти</button>
            <a class="btn btn-ghost" href="catalog.php">Сбросить</a>
        </div>

    </div>

</form>


<?php if ($isSearch && $errors === []): ?>
    <p class="result-info">Найдено тортов: <?= count($cakes) ?></p>
<?php endif; ?>

<?php if ($errors !== []): ?>

    <p class="error-message">Исправьте ошибки в форме поиска.</p>

<?php elseif ($cakes === []): ?>

    <div class="empty">
        <p><?= $isSearch ? 'По вашему запросу ничего не найдено. Попробуйте изменить условия поиска.' : 'Тортов пока нет.' ?></p>
    </div>

<?php else: ?>

    <div class="products">
        <?php foreach ($cakes as $cake): ?>
            <?php require __DIR__ . '/cake_card.php'; ?>
        <?php endforeach; ?>
    </div>

<?php endif; ?>