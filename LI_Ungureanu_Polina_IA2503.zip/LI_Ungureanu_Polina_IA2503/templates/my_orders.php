<?php

//список заказов клиента

/**
 * @var string $success
 * @var array $orders
 * @var array $decors
 * @var array $statuses
 */
?>

<h2>Мои заказы</h2>

<?php if ($success !== ''): ?>
    <p class="success"><?= h($success) ?></p>
<?php endif; ?>

<?php if ($orders === []): ?>

    <p>У вас пока нет заказов. <a href="catalog.php">Выбрать торт</a></p>

<?php else: ?>

    <table>
        <thead>
            <tr>
                <th>№</th>
                <th>Торт</th>
                <th>Начинка</th>
                <th>Декор</th>
                <th>Надпись</th>
                <th>Дата получения</th>
                <th>Упаковка</th>
                <th>Сумма</th>
                <th>Статус</th>
            </tr>
        </thead>

        <tbody>
            <?php foreach ($orders as $order): ?>
                <?php $imageUrl = getCakeImageUrl($order['cake_image']); ?>

                <tr>
                    <td><?= h((string) $order['id']) ?></td>

                    <td>
                        <?php if ($imageUrl !== null): ?>
                            <img class="cake-thumb" src="<?= h($imageUrl) ?>" alt="<?= h($order['cake_title']) ?>">
                        <?php endif; ?>
                        <?= h($order['cake_title']) ?>
                    </td>

                    <td><?= h($order['filling_name']) ?></td>

                    <td><?= h($decors[$order['decor']] ?? $order['decor']) ?></td>

                    <td><?= h($order['inscription'] !== '' ? $order['inscription'] : '-') ?></td>

                    <td><?= h(formatDate($order['pickup_date'])) ?></td>

                    <td><?= $order['gift_box'] ? 'Да' : 'Нет' ?></td>

                    <td><?= h((string) $order['total_price']) ?> лей</td>

                    <td><span class="badge"><?= h($statuses[$order['status']] ?? $order['status']) ?></span></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

<?php endif; ?>