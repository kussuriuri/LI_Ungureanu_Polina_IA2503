<?php

//форма регистрации (используется и для создания администратора)

/**
 * @var string $formTitle
 * @var string $formAction
 * @var string $buttonText
 * @var array $errors
 * @var array $data
 */
?>

<div class="auth">

    <h2><?= h($formTitle) ?></h2>

    <form action="<?= h($formAction) ?>" method="post">

        <label for="name">Имя:</label>

        <input
            type="text"
            name="name"
            id="name"
            minlength="2"
            maxlength="50"
            required
            value="<?= h($data['name']) ?>"
        >

        <?php getErrors($errors, 'name'); ?>


        <label for="email">Email:</label>

        <input
            type="email"
            name="email"
            id="email"
            maxlength="100"
            required
            value="<?= h($data['email']) ?>"
        >

        <?php getErrors($errors, 'email'); ?>


        <label for="password">Пароль (от 8 символов, буквы и цифры):</label>

        <input
            type="password"
            name="password"
            id="password"
            minlength="8"
            maxlength="72"
            required
        >

        <?php getErrors($errors, 'password'); ?>


        <label for="password_confirm">Повторите пароль:</label>

        <input
            type="password"
            name="password_confirm"
            id="password_confirm"
            minlength="8"
            maxlength="72"
            required
        >

        <?php getErrors($errors, 'password_confirm'); ?>


        <button type="submit"><?= h($buttonText) ?></button>

    </form>

    <?php if ($formAction === 'register.php'): ?>
        <p>Уже есть аккаунт? <a href="login.php">Войти</a></p>
    <?php endif; ?>

</div>