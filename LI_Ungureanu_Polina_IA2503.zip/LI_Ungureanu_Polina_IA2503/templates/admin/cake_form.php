<?php

//форма добавления и редактирования торта

/**
 * @var string $formTitle
 * @var string $formAction
 * @var string $buttonText
 * @var array $errors
 * @var array $data
 */
?>

<h2><?= h($formTitle) ?></h2>

<form action="<?= h($formAction) ?>" method="post">

    <label for="title">Название:</label>

    <input
        type="text"
        name="title"
        id="title"
        minlength="3"
        maxlength="50"
        required
        value="<?= h($data['title']) ?>"
    >

    <?php getErrors($errors, 'title'); ?>


    <label for="flavor">Вкус:</label>

    <input
        type="text"
        name="flavor"
        id="flavor"
        minlength="2"
        maxlength="50"
        required
        value="<?= h($data['flavor']) ?>"
    >

    <?php getErrors($errors, 'flavor'); ?>


    <label for="description">Описание:</label>

    <textarea
        name="description"
        id="description"
        minlength="10"
        maxlength="500"
        required
    ><?= h($data['description']) ?></textarea>

    <?php getErrors($errors, 'description'); ?>


    <label for="price">Цена (лей):</label>

    <input
        type="number"
        name="price"
        id="price"
        min="1"
        max="100000"
        required
        value="<?= h((string) $data['price']) ?>"
    >

    <?php getErrors($errors, 'price'); ?>


    <label class="option">
        <input
            type="checkbox"
            name="is_available"
            value="1"
            <?= $data['is_available'] ? 'checked' : '' ?>
        >
        В наличии (доступен для заказа)
    </label>

    <?php getErrors($errors, 'is_available'); ?>


    <button type="submit"><?= h($buttonText) ?></button>
    <a href="admin_cakes.php">Отмена</a>

</form>