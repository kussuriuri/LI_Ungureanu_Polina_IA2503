<?php

//все заказы в админ-панели

/**
 * @var array $orders
 * @var array $decors
 * @var array $statuses
 */
?>

<h2>Все заказы</h2>

<?php if ($orders === []): ?>

    <p>Заказов пока нет.</p>

<?php else: ?>

    <table>
        <thead>
            <tr>
                <th>№</th>
                <th>Клиент</th>
                <th>Торт</th>
                <th>Начинка</th>
                <th>Декор и надпись</th>
                <th>Получение</th>
                <th>Сумма</th>
                <th>Статус</th>
            </tr>
        </thead>

        <tbody>
            <?php foreach ($orders as $order): ?>
                <tr>
                    <td><?= h((string) $order['id']) ?></td>

                    <td>
                        <?= h($order['user_name']) ?><br>
                        <span class="meta"><?= h($order['user_email']) ?></span>
                    </td>

                    <td><?= h($order['cake_title']) ?></td>

                    <td><?= h($order['filling_name']) ?></td>

                    <td>
                        <?= h($decors[$order['decor']] ?? $order['decor']) ?><br>
                        <span class="meta"><?= h($order['inscription'] !== '' ? $order['inscription'] : 'без надписи') ?></span>
                        <?php if ($order['comment'] !== ''): ?>
                            <br><span class="meta">Пожелания: <?= h($order['comment']) ?></span>
                        <?php endif; ?>
                    </td>

                    <td>
                        <?= h(formatDate($order['pickup_date'])) ?>
                        <?= $order['gift_box'] ? '<br><span class="meta">+ подарочная упаковка</span>' : '' ?>
                    </td>

                    <td><?= h((string) $order['total_price']) ?> лей</td>

                    <td>
                        <form action="admin_orders.php" method="post">
                            <input type="hidden" name="action" value="set_status">

                            <input
                                type="hidden"
                                name="order_id"
                                value="<?= h((string) $order['id']) ?>"
                            >

                            <select name="status">
                                <?php foreach ($statuses as $code => $name): ?>
                                    <option
                                        value="<?= h($code) ?>"
                                        <?= $order['status'] === $code ? 'selected' : '' ?>
                                    >
                                        <?= h($name) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>

                            <button type="submit">Сохранить</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

<?php endif; ?>