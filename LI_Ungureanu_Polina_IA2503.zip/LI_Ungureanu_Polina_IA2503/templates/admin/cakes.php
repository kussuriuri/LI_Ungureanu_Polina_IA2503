<?php

//список тортов в админ-панели

/**
 * @var string $success
 * @var string $error
 * @var array $cakes
 */
?>

<h2>Управление тортами</h2>

<?php if ($success !== ''): ?>
    <p class="success"><?= h($success) ?></p>
<?php endif; ?>

<?php if ($error !== ''): ?>
    <p class="error-message"><?= h($error) ?></p>
<?php endif; ?>

<p><a class="btn" href="admin_cake_add.php">Добавить торт</a></p>

<?php if ($cakes === []): ?>

    <p>Тортов пока нет.</p>

<?php else: ?>

    <table>
        <thead>
            <tr>
                <th>Название</th>
                <th>Вкус</th>
                <th>Цена</th>
                <th>В наличии</th>
                <th>Добавлен</th>
                <th>Действия</th>
            </tr>
        </thead>

        <tbody>
            <?php foreach ($cakes as $cake): ?>
                <tr>
                    <td><?= h($cake['title']) ?></td>

                    <td><?= h($cake['flavor']) ?></td>

                    <td><?= h((string) $cake['price']) ?> лей</td>

                    <td><?= $cake['is_available'] ? 'Да' : 'Нет' ?></td>

                    <td><?= h(formatDate($cake['created_at'])) ?></td>

                    <td>
                        <a href="admin_cake_edit.php?id=<?= h((string) $cake['id']) ?>">Редактировать</a>

                        <form action="admin_cakes.php" method="post" onsubmit="return confirm('Удалить торт?');">
                            <input type="hidden" name="action" value="delete">

                            <input
                                type="hidden"
                                name="delete_id"
                                value="<?= h((string) $cake['id']) ?>"
                            >

                            <button type="submit">Удалить</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

<?php endif; ?>