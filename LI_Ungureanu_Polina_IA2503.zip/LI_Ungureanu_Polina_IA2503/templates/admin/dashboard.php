<?php

//главная страница админ-панели

?>

<h2>Админ-панель</h2>

<div class="cards">
    <div class="card">
        <h3>Торты</h3>
        <p>Добавление, редактирование, удаление, снятие с продажи.</p>
        <a class="btn" href="admin_cakes.php">Управлять</a>
    </div>

    <div class="card">
        <h3>Заказы</h3>
        <p>Все заказы клиентов и смена их статусов.</p>
        <a class="btn" href="admin_orders.php">Открыть</a>
    </div>

    <div class="card">
        <h3>Пользователи</h3>
        <p>Список пользователей, смена ролей, удаление.</p>
        <a class="btn" href="admin_users.php">Открыть</a>
    </div>

    <div class="card">
        <h3>Новый администратор</h3>
        <p>Создание учётной записи с ролью администратора.</p>
        <a class="btn" href="admin_create_admin.php">Создать</a>
    </div>
</div>