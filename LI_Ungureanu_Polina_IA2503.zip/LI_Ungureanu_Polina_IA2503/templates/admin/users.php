<?php

//список пользователей в админ-панели

/**
 * @var string $success
 * @var string $error
 * @var array $users
 * @var array $currentUser
 */
?>

<h2>Пользователи</h2>

<?php if ($success !== ''): ?>
    <p class="success"><?= h($success) ?></p>
<?php endif; ?>

<?php if ($error !== ''): ?>
    <p class="error-message"><?= h($error) ?></p>
<?php endif; ?>

<p><a class="btn" href="admin_create_admin.php">Создать администратора</a></p>

<table>
    <thead>
        <tr>
            <th>Имя</th>
            <th>Email</th>
            <th>Роль</th>
            <th>Регистрация</th>
            <th>Действия</th>
        </tr>
    </thead>

    <tbody>
        <?php foreach ($users as $user): ?>
            <tr>
                <td><?= h($user['name']) ?></td>

                <td><?= h($user['email']) ?></td>

                <td><?= $user['role'] === 'admin' ? 'администратор' : 'клиент' ?></td>

                <td><?= h(formatDate($user['created_at'])) ?></td>

                <td>
                    <?php if ((int) $user['id'] === (int) $currentUser['id']): ?>

                        <span class="meta">это вы</span>

                    <?php else: ?>

                        <form action="admin_users.php" method="post">
                            <input type="hidden" name="action" value="set_role">

                            <input
                                type="hidden"
                                name="user_id"
                                value="<?= h((string) $user['id']) ?>"
                            >

                            <select name="role">
                                <option value="client" <?= $user['role'] === 'client' ? 'selected' : '' ?>>клиент</option>
                                <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : '' ?>>администратор</option>
                            </select>

                            <button type="submit">Сменить роль</button>
                        </form>

                        <form action="admin_users.php" method="post" onsubmit="return confirm('Удалить пользователя вместе с его заказами?');">
                            <input type="hidden" name="action" value="delete">

                            <input
                                type="hidden"
                                name="user_id"
                                value="<?= h((string) $user['id']) ?>"
                            >

                            <button type="submit">Удалить</button>
                        </form>

                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>