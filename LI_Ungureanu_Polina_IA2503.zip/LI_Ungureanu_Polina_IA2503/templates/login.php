<?php

//форма входа

/**
 * @var string $success
 * @var array $errors
 * @var array $data
 */
?>

<div class="auth">

    <h2>Вход</h2>

    <?php if ($success !== ''): ?>
        <p class="success"><?= h($success) ?></p>
    <?php endif; ?>

    <form action="login.php" method="post">

        <label for="email">Email:</label>

        <input
            type="email"
            name="email"
            id="email"
            required
            value="<?= h($data['email']) ?>"
        >

        <?php getErrors($errors, 'email'); ?>


        <label for="password">Пароль:</label>

        <input
            type="password"
            name="password"
            id="password"
            required
        >

        <?php getErrors($errors, 'password'); ?>


        <button type="submit">Войти</button>

    </form>

    <p>Нет аккаунта? <a href="register.php">Зарегистрироваться</a></p>

</div>