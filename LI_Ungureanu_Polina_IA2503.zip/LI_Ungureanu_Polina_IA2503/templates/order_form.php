<?php

//форма заказа торта

/**
 * @var array $errors
 * @var array $data
 * @var array $cakes
 * @var array $fillings
 * @var array $decors
 * @var array $dateRange
 * @var int $giftBoxPrice
 */
?>

<div class="order-page">
<h2>Заказать торт</h2>

<img id="cake-preview" class="cake-img large" src="" alt="" hidden>

<form action="order.php" method="post">

    <label for="cake_id">Торт:</label>

    <select name="cake_id" id="cake_id" required>
        <option value="">Выберите торт</option>

        <?php foreach ($cakes as $cake): ?>
            <option
                value="<?= h((string) $cake['id']) ?>"
                data-image="<?= h(getCakeImageUrl($cake['image']) ?? '') ?>"
                <?= (string) $cake['id'] === (string) $data['cake_id'] ? 'selected' : '' ?>
            >
                <?= h($cake['title']) ?> - <?= h((string) $cake['price']) ?> лей
            </option>
        <?php endforeach; ?>

    </select>

    <?php getErrors($errors, 'cake_id'); ?>


    <label for="filling_id">Начинка:</label>

    <select name="filling_id" id="filling_id" required>
        <option value="">Выберите начинку</option>

        <?php foreach ($fillings as $filling): ?>
            <option
                value="<?= h((string) $filling['id']) ?>"
                <?= (string) $filling['id'] === (string) $data['filling_id'] ? 'selected' : '' ?>
            >
                <?= h($filling['name']) ?><?= (int) $filling['extra_price'] > 0 ? ' (+' . h((string) $filling['extra_price']) . ' лей)' : '' ?>
            </option>
        <?php endforeach; ?>

    </select>

    <?php getErrors($errors, 'filling_id'); ?>


    <p><strong>Декор:</strong></p>

    <?php foreach ($decors as $code => $name): ?>
        <label class="option">
            <input
                type="radio"
                name="decor"
                value="<?= h($code) ?>"
                required
                <?= $data['decor'] === $code ? 'checked' : '' ?>
            >
            <?= h($name) ?>
        </label>
    <?php endforeach; ?>

    <?php getErrors($errors, 'decor'); ?>


    <label for="inscription">Надпись на торте (необязательно, до 40 символов):</label>

    <input
        type="text"
        name="inscription"
        id="inscription"
        maxlength="40"
        value="<?= h($data['inscription']) ?>"
    >

    <?php getErrors($errors, 'inscription'); ?>


    <label for="pickup_date">Дата получения:</label>

    <input
        type="date"
        name="pickup_date"
        id="pickup_date"
        min="<?= h($dateRange['min']) ?>"
        max="<?= h($dateRange['max']) ?>"
        required
        value="<?= h($data['pickup_date']) ?>"
    >

    <?php getErrors($errors, 'pickup_date'); ?>


    <label for="comment">Пожелания (необязательно, до 300 символов):</label>

    <textarea
        name="comment"
        id="comment"
        maxlength="300"
    ><?= h($data['comment']) ?></textarea>

    <?php getErrors($errors, 'comment'); ?>


    <label class="option">
        <input
            type="checkbox"
            name="gift_box"
            value="1"
            <?= $data['gift_box'] ? 'checked' : '' ?>
        >
        Подарочная упаковка (+<?= h((string) $giftBoxPrice) ?> лей)
    </label>

    <?php getErrors($errors, 'gift_box'); ?>


    <button type="submit">Оформить заказ</button>

</form>
</div>
<script>
    // при выборе торта показываем его картинку над формой
    const cakeSelect = document.getElementById('cake_id');
    const cakePreview = document.getElementById('cake-preview');

    function updateCakePreview() {
        const option = cakeSelect.options[cakeSelect.selectedIndex];
        const url = option.dataset.image || '';

        if (url === '') {
            cakePreview.hidden = true; // у торта нет картинки или он не выбран
            return;
        }

        cakePreview.src = url;
        cakePreview.alt = option.textContent.trim();
        cakePreview.hidden = false;
    }

    cakeSelect.addEventListener('change', updateCakePreview);
    updateCakePreview(); // при открытии страницы (например, order.php?cake_id=3)
</script>