<?php

//все заказы и смена статусов

require_once __DIR__ . '/../src/functions.php';
require_once __DIR__ . '/../src/handler.php';

$currentUser = requireAdmin();

handleUpdateOrderStatus();//проверка запроса перед изм статуса заказа

$title = 'Все заказы';
$orders = getAllOrders();
$decors = getDecors();
$statuses = getOrderStatuses();
$parts = ['admin/orders.php'];

require __DIR__ . '/../templates/layout.php';