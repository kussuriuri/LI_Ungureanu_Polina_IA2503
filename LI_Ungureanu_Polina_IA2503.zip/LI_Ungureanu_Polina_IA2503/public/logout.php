<?php

//выход из системы (работает только на POST-запрос)

require_once __DIR__ . '/../src/functions.php';
require_once __DIR__ . '/../src/handler.php';

handleLogout();

header('Location: index.php'); // если зашли по ссылке (GET) - просто на главную
exit;