<?php

//страница одного торта

require_once __DIR__ . '/../src/functions.php';
require_once __DIR__ . '/../src/handler.php';

$id = filter_var($_GET['id'] ?? '', FILTER_VALIDATE_INT); // получаем id из url и проверяем, что это целое число
$cake = ($id === false) ? null : getCakeById($id);

if ($cake === null) {
    http_response_code(404);
    echo 'Торт не найден.';
    exit;
}

$title = $cake['title'];
$currentUser = getCurrentUser();
$parts = ['cake.php'];

require __DIR__ . '/../templates/layout.php';