<?php

//главная стр

require_once __DIR__ . '/../src/functions.php';
require_once __DIR__ . '/../src/handler.php';

$title = 'Bento Cake Studio';
$currentUser = getCurrentUser();
$newCakes = getNewCakes(3);
$fillings = getFillings();
$parts = ['home.php'];

require __DIR__ . '/../templates/layout.php';//перем до require доступны в подкл файле