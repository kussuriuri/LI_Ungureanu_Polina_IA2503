<?php

//управление тортами: список и удаление

require_once __DIR__ . '/../src/functions.php';
require_once __DIR__ . '/../src/handler.php';

$currentUser = requireAdmin();

handleDeleteCake(); // проверка не пришел ли запрос на удаление

$messages = [
    'created' => 'Торт добавлен.',
    'updated' => 'Торт обновлён.',
    'deleted' => 'Торт удалён.',
];

$success = $messages[getQueryString('success')] ?? '';
$error = '';

if (getQueryString('error') === 'has_orders') {
    $error = 'Нельзя удалить торт, на который есть заказы. Снимите его с продажи: откройте редактирование и уберите галочку «В наличии».';
}

$title = 'Управление тортами';
$cakes = getAllCakes();
$parts = ['admin/cakes.php'];

require __DIR__ . '/../templates/layout.php';