<?php

//заказы текущего пользователя

require_once __DIR__ . '/../src/functions.php';
require_once __DIR__ . '/../src/handler.php';

$currentUser = requireLogin();

$success = '';

if (($_GET['success'] ?? '') === '1') {//если в url есть 
    $success = 'Заказ успешно оформлен!';
}

$title = 'Мои заказы';
$orders = getOrdersByUser((int) $currentUser['id']);
$decors = getDecors();
$statuses = getOrderStatuses();
$parts = ['my_orders.php'];//имя шаблона

require __DIR__ . '/../templates/layout.php';