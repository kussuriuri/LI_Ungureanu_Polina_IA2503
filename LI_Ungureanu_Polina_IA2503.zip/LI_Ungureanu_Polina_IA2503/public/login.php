<?php

//страница входа

require_once __DIR__ . '/../src/functions.php';
require_once __DIR__ . '/../src/handler.php';

redirectIfLoggedIn();

$form = new LoginForm(new Validator());
handleLogin($form);

$success = '';

if (($_GET['registered'] ?? '') === '1') {
    $success = 'Регистрация прошла успешно! Теперь можно войти.';
}

// переменные для шаблонов
$title = 'Вход';
$currentUser = null;
$errors = $form->errors;
$data = $form->data;
$parts = ['login.php'];

require __DIR__ . '/../templates/layout.php';