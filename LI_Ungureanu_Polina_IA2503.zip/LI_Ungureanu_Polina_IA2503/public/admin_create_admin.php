<?php

//создание нового администратора

require_once __DIR__ . '/../src/functions.php';
require_once __DIR__ . '/../src/handler.php';

$currentUser = requireAdmin();

$form = new RegisterForm(new Validator()); // та же форма и проверки, что при регистрации
handleCreateAdmin($form);

// переменные для шаблонов
$title = 'Создать администратора';
$formTitle = 'Создать администратора';
$formAction = 'admin_create_admin.php';
$buttonText = 'Создать';
$errors = $form->errors;
$data = $form->data;
$parts = ['register.php'];

require __DIR__ . '/../templates/layout.php';