<?php

//редактирование торта

require_once __DIR__ . '/../src/functions.php';
require_once __DIR__ . '/../src/handler.php';

$currentUser = requireAdmin();

$id = filter_var(getQueryString('id'), FILTER_VALIDATE_INT); // id из url + проверка на целое число
$cake = ($id === false) ? null : getCakeById($id);

if ($cake === null) {
    http_response_code(404);
    echo 'Торт не найден.';
    exit;
}

$form = new CakeForm(new Validator());
$form->data = $cake; // форма сначала показывает текущие данные торта; копир туда
handleUpdateCake($id, $form);//update

$title = 'Редактирование торта';
$formTitle = 'Редактировать торт';
$formAction = 'admin_cake_edit.php?id=' . $id;
$buttonText = 'Сохранить';
$errors = $form->errors;
$data = $form->data;
$parts = ['admin/cake_form.php'];

require __DIR__ . '/../templates/layout.php';