<?php

//страница регистрации

require_once __DIR__ . '/../src/functions.php';
require_once __DIR__ . '/../src/handler.php';

redirectIfLoggedIn(); // вошедшему пользователю регистрация не нужна

$form = new RegisterForm(new Validator());
handleRegister($form); // обработка формы (если отправлена и данные правильные - редирект на вход)

// переменные для шаблонов
$title = 'Регистрация';
$currentUser = null;
$formTitle = 'Регистрация';
$formAction = 'register.php';
$buttonText = 'Зарегистрироваться';
$errors = $form->errors;
$data = $form->data;
$parts = ['register.php'];

require __DIR__ . '/../templates/layout.php';