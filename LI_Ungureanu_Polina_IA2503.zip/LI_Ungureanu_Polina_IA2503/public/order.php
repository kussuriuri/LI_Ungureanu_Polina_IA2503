<?php

//страница оформления заказа - провер авторизацию 

require_once __DIR__ . '/../src/functions.php';//общ ф-ии;
require_once __DIR__ . '/../src/handler.php';//тут подкл все остальные файлы

$currentUser = requireLogin(); // гостя перенаправит на страницу входа и получ его данные

$form = new OrderForm(new Validator());//обраб данные заказа и возвр ; подготав пустой массив ошибок и данные для заполнения пользователем
//получ торта из url
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { // торт можно выбрать заранее: order.php?cake_id=3
    $cakeId = filter_var($_GET['cake_id'] ?? '', FILTER_VALIDATE_INT);//знач из url = цел число?

    if ($cakeId !== false) {
        $form->data['cake_id'] = (string) $cakeId;//выбранный торт подстав в данные формы
    }
}

handleCreateOrder($form, (int) $currentUser['id']);//проверка создания заказа и при успехе созд заказ
//ч/з внутр handle(получ данные)

// переменные для шаблонов
$title = 'Заказать торт';
$errors = $form->errors;
$data = $form->data;
$cakes = getAvailableCakes();
$fillings = getFillings();
$decors = getDecors();
$dateRange = getPickupDateRange();
$giftBoxPrice = getGiftBoxPrice();
$parts = ['order_form.php'];//массив с именем шаблона, кот нужно подк для отображ одержимого стр 

require __DIR__ . '/../templates/layout.php';