<?php

//главная страница админ-панели

require_once __DIR__ . '/../src/functions.php';
require_once __DIR__ . '/../src/handler.php';

$currentUser = requireAdmin();

$title = 'Админ-панель';
$parts = ['admin/dashboard.php'];

require __DIR__ . '/../templates/layout.php';