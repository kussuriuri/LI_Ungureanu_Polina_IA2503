<?php

//управление пользователями

require_once __DIR__ . '/../src/functions.php';
require_once __DIR__ . '/../src/handler.php';

$currentUser = requireAdmin();

handleUserActions((int) $currentUser['id']);//обраб действ текущ польз(удал сам себя)

$messages = [
    'role' => 'Роль изменена.',
    'deleted' => 'Пользователь удалён.',
    'admin_created' => 'Администратор создан.',
];

$success = $messages[getQueryString('success')] ?? '';//сообщ странице какое действ было успеш выполнено
$error = '';

if (getQueryString('error') === 'self') {//если этот парам в адрес строке = self
    $error = 'Нельзя изменить или удалить собственную учётную запись.';
}

$title = 'Пользователи';
$users = getAllUsers();
$parts = ['admin/users.php'];

require __DIR__ . '/../templates/layout.php';