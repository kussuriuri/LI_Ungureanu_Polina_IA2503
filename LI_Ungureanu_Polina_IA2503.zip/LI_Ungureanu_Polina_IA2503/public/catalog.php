<?php

//каталог тортов с поиском

require_once __DIR__ . '/../src/functions.php';
require_once __DIR__ . '/../src/handler.php';

$flavors = getFlavors();

$form = new SearchForm(new Validator());
$form->handle($flavors); // читает параметры поиска из адресной строки

// переменные для шаблонов
$title = 'Каталог тортов';
$currentUser = getCurrentUser();
$errors = $form->errors;
$data = $form->data;
$isSearch = $_GET !== []; // true, если пользователь отправил форму поиска
$cakes = ($errors === []) ? searchCakes($data) : []; // при ошибках в параметрах ничего не ищем
$parts = ['catalog.php'];

require __DIR__ . '/../templates/layout.php';