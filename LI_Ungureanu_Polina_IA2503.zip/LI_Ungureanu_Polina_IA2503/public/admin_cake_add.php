<?php

//добавление торта

require_once __DIR__ . '/../src/functions.php';
require_once __DIR__ . '/../src/handler.php';

$currentUser = requireAdmin();

$form = new CakeForm(new Validator());
handleCreateCake($form);//провер рез-ы handle и реш можно ли созд торт

$title = 'Добавить торт';
$formTitle = 'Добавить торт';
$formAction = 'admin_cake_add.php';
$buttonText = 'Добавить';
$errors = $form->errors;
$data = $form->data;
$parts = ['admin/cake_form.php'];

require __DIR__ . '/../templates/layout.php';