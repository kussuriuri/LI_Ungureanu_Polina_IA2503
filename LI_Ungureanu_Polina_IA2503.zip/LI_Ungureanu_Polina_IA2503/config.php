<?php
// параметры подключения к базе данных 
return [
    'host' => 'localhost', //адрес серва БД -этот комп
    'port' => '5432',
    'dbname' => 'bento',
    'user' => 'polina',
    'password' => '',
];