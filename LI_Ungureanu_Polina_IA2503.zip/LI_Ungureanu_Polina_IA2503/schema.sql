SET client_encoding = 'UTF8'; -- кодировка клиента, коррект передающая русские символы

CREATE TABLE users (
    id SERIAL PRIMARY KEY,                -- автоинкремент
    name VARCHAR(50) NOT NULL,   
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(10) NOT NULL DEFAULT 'client'
        CHECK (role IN ('client', 'admin')), -- знач role должно быть либо то либо то
    created_at TIMESTAMP NOT NULL DEFAULT NOW() -- текущ дата и время 
);

CREATE TABLE fillings (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    extra_price INT NOT NULL DEFAULT 0 CHECK (extra_price >= 0) -- доплата не мб отриц
);

CREATE TABLE cakes (
    id SERIAL PRIMARY KEY,
    title VARCHAR(50) NOT NULL,
    flavor VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    price INT NOT NULL CHECK (price > 0),
    is_available BOOLEAN NOT NULL DEFAULT TRUE, -- есть ли торт в продаже
    image VARCHAR(255) NOT NULL DEFAULT '',
    created_at DATE NOT NULL DEFAULT CURRENT_DATE --только текущ календар дата
);

CREATE TABLE orders (
    id SERIAL PRIMARY KEY,
    user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE, -- при удал связанной записи - авт удал зависимые записи; удалили пользователя - удалились его заказы
    cake_id INT NOT NULL REFERENCES cakes(id),
    filling_id INT NOT NULL REFERENCES fillings(id),
    decor VARCHAR(20) NOT NULL
        CHECK (decor IN ('minimal', 'flowers', 'berries', 'retro')),
    inscription VARCHAR(40) NOT NULL DEFAULT '',
    pickup_date DATE NOT NULL,
    comment TEXT NOT NULL DEFAULT '', 
    gift_box BOOLEAN NOT NULL DEFAULT FALSE,
    total_price INT NOT NULL, 
    status VARCHAR(20) NOT NULL DEFAULT 'new'
        CHECK (status IN ('new', 'in_progress', 'ready', 'done', 'cancelled')),
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- начальные данные
INSERT INTO fillings (name, description, extra_price) VALUES
    ('Сливочный сыр', 'Классический нежный крем на сливочном сыре', 0),
    ('Ягодный конфитюр', 'Домашний конфитюр из лесных ягод с кислинкой', 30),
    ('Солёная карамель', 'Тягучая карамель с щепоткой морской соли', 40),
    ('Фисташковый крем', 'Крем на основе настоящей фисташковой пасты', 60),
    ('Малина-маскарпоне', 'Лёгкий маскарпоне со свежей малиной', 50);

INSERT INTO cakes (title, flavor, description, price, image, created_at) VALUES
    ('Ванильное облако', 'ваниль', 'Нежный ванильный бисквит с лёгким кремом', 350, 'vanilla.jpg', CURRENT_DATE - 60),
    ('Шоколадный бархат', 'шоколад', 'Шоколадный бисквит и ганаш из тёмного шоколада', 390, 'chocolate.jpg', CURRENT_DATE - 45),
    ('Клубничный каприз', 'клубника', 'Бисквит с клубничным конфитюром и воздушным кремом', 420, 'strawberry.jpg', CURRENT_DATE - 30),
    ('Фисташковая мечта', 'фисташка', 'Фисташковый бисквит с кремом из фисташковой пасты', 480, 'pistachio.jpg', CURRENT_DATE - 14),
    ('Лимонный сорбет', 'лимон', 'Лимонный бисквит со сливочно-лимонным курдом', 370, 'lemon.jpg', CURRENT_DATE - 5),
    ('Красный бархат', 'красный бархат', 'Классический красный бархат с кремом на сливочном сыре', 410, 'red-velvet.jpg', CURRENT_DATE - 1);


-- Чтобы сделать пользователя администратором (после регистрации через сайт):
-- UPDATE users SET role = 'admin' WHERE email = 'your@email.com';