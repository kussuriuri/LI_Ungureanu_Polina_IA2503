<?php

/**
 * функции управления пользователями для администратора
 */

require_once __DIR__ . '/functions.php';

/**
 * Возвращает допустимые роли пользователей.
 *
 * @return array Список кодов ролей
 */
function getRoles(): array
{
    return ['client', 'admin'];
}

/**
 * Возвращает всех пользователей.
 *
 * @return array Массив пользователей (без хеша пароля)
 */
function getAllUsers(): array
{
    return getPdo()->query('SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC')->fetchAll();//в подключении делаем запрос
}

/**
 * Меняет роль пользователя.
 *
 * @param int $id ID пользователя
 * @param string $role Новая роль (client или admin)
 * @return void
 */
function updateUserRole(int $id, string $role): void
{
    $stmt = getPdo()->prepare('UPDATE users SET role = :role WHERE id = :id');
    $stmt->execute(['id' => $id, 'role' => $role]);
}

/**
 * Удаляет пользователя вместе с его заказами (каскадно, это задано в схеме БД).
 *
 * @param int $id ID пользователя
 * @return void
 */
function deleteUser(int $id): void
{
    $stmt = getPdo()->prepare('DELETE FROM users WHERE id = :id');
    $stmt->execute(['id' => $id]);
}