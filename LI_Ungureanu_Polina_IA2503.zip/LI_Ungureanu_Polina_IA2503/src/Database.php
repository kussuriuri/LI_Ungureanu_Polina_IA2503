<?php

//Получает параметры из config.php и создаёт соединение PDO

/**
 * Database.php создаёт подключение к PostgreSQL и предоставляет другим частям программы доступ к этому подключению
 */
class Database
{
    /** @var PDO Соединение с базой данных */
    private PDO $pdo; //обьект PDO

    /**
     * Создает подключение к базе данных.
     *
     * @param array $config Параметры подключения:
     * host, port, dbname, user, password
     */
    public function __construct(array $config)
    {
        $dsn = 'pgsql:host=' . $config['host'] . ';port=' . $config['port'] . ';dbname=' . $config['dbname'];// строка подключения из данных config -> сообщ PDO к какой БД подкл

        $this->pdo = new PDO( // созд подкл - нов об PDO
            $dsn,
            $config['user'],
            $config['password']
        );

        $this->pdo->setAttribute(//установка настройки у об PDO
            PDO::ATTR_ERRMODE,// режим обработки ошибок
            PDO::ERRMODE_EXCEPTION // выбрасывать исключения при ошибках
        );

        $this->pdo->setAttribute( // способ получения результатов запроса
            PDO::ATTR_DEFAULT_FETCH_MODE,//настройка режима получ данных
            PDO::FETCH_ASSOC 
        );
    }

    /**
     * Возвращает готовое соединение с базой данных.
     *
     * @return PDO Объект соединения
     */
    public function getConnection(): PDO
    {
        return $this->pdo;
    }
}