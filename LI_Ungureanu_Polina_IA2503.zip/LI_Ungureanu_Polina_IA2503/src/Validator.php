<?php

/**
 * Класс для проверки данных всех форм приложения.
 */
class Validator
{
    /**
     * Проверяет, что обязательное поле не пустое.
     *
     * @param string $value Значение поля
     * @return bool true, если поле заполнено
     */
    public function validateRequired(string $value): bool
    {
        return $value !== '';
    }

    /**
     * Проверяет длину строки.
     *
     * @param string $value Проверяемая строка
     * @param int $min Минимальная длина
     * @param int $max Максимальная длина
     * @return bool true, если длина находится в допустимом диапазоне
     */
    public function validateLength(string $value, int $min, int $max): bool
    {
        $length = mb_strlen($value, 'UTF-8'); // mb_strlen корректно считает русские буквы

        if ($length < $min || $length > $max) {
            return false;
        }

        return true;
    }

    /**
     * Проверяет, что строка является корректным email-адресом.
     *
     * @param string $email Введённый email
     * @return bool true, если формат email корректен
     */
    public function validateEmail(string $email): bool
    {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false; //FILTER_VALIDATE_EMAIL - явл ли корректным email-ом; возвр t/f
    }

    /**
     * Проверяет, что имя состоит только из букв, пробелов и дефиса.
     *
     * @param string $name Введённое имя
     * @return bool true, если имя содержит допустимые символы
     */
    public function validateName(string $name): bool{
    $letters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZабвгдеёжзийклмнопрстуфхцчшщъыьэюяАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ';

    if ($name === '') {
        return false;
    }

    $characters = mb_str_split($name);//разбив имя на отдельные символы

    foreach ($characters as $character) {
        if ($character === ' ' || $character === '-') {
            continue;
        }

        if (mb_strpos($letters, $character) === false) {//если символ в строке не из letters
            return false;
        }
    }

    return true;
    }

    /**
     * Проверяет надёжность пароля: хотя бы одна буква и одна цифра.
     *
     * @param string $password Введённый пароль
     * @return bool true, если пароль содержит и буквы, и цифры
     */
    public function validatePasswordStrength(string $password): bool{
    $letters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZабвгдеёжзийклмнопрстуфхцчшщъыьэюяАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ';

    $hasLetter = false;
    $hasNumber = false;

    $characters = mb_str_split($password);

    foreach ($characters as $character) {
        if (mb_strpos($letters, $character) !== false) {//если символ есть в letters
            $hasLetter = true;
        }

        if ($character >= '0' && $character <= '9') {//если символ цифра
            $hasNumber = true;
        }
    }

    return $hasLetter && $hasNumber; 
    }

    /**
     * Проверяет, что значение входит в список разрешённых (строгое сравнение).
     *
     * @param string $value Выбранное пользователем значение
     * @param array $allowedValues Список допустимых значений
     * @return bool true, если значение допустимо
     */
    public function validateInList(string $value, array $allowedValues): bool//знач и разреш список; true = строг сравн
    {
        return in_array($value, $allowedValues, true); 
    }

    /**
     * Проверяет правильность даты в формате YYYY-MM-DD.
     *
     * @param string $date Введённая дата
     * @return bool true, если дата существует и формат корректен
     */
    public function validateDate(string $date): bool
    {
        $dateTime = DateTime::createFromFormat('Y-m-d', $date);//у класса DateTime выз метод кот созд дату из строки

        if ($dateTime === false) {//если у метода не получ созд дату
            return false;
        }

        return $dateTime->format('Y-m-d') === $date; // отсекает несуществующие даты вроде 2026-02-31
    }

    /**
     * Проверяет, что дата входит в заданный диапазон.
     *
     * @param string $date Проверяемая дата (YYYY-MM-DD)
     * @param string $min Минимальная дата (YYYY-MM-DD)
     * @param string $max Максимальная дата (YYYY-MM-DD)
     * @return bool true, если дата в диапазоне
     */
    public function validateDateRange(string $date, string $min, string $max): bool
    {
        return $date >= $min && $date <= $max; // формат Y-m-d позволяет сравнивать даты как строки
    }

    /**
     * Проверяет, что строка является целым числом в заданных границах.
     *
     * @param string $value Проверяемое значение
     * @param int $min Минимум
     * @param int $max Максимум
     * @return bool true, если это целое число из диапазона
     */
    public function validateIntRange(string $value, int $min, int $max): bool
    {
        $number = filter_var($value, FILTER_VALIDATE_INT); // false, если это не целое число

        return $number !== false && $number >= $min && $number <= $max;
    }

    /**
     * Проверяет все данные формы регистрации.
     *
     * @param array $data Данные формы: name, email, password, password_confirm
     * @return array Массив ошибок для каждого поля. Если ошибок нет — пустой массив.
     */
    public function validateRegister(array $data): array
    {
        $errors = [];

        if (!$this->validateRequired($data['name'])) {//если не прошло проверку
            $errors['name'][] = 'Введите имя.';
        } elseif (!$this->validateLength($data['name'], 2, 50)) {
            $errors['name'][] = 'Имя должно содержать от 2 до 50 символов.';
        } elseif (!$this->validateName($data['name'])) {
            $errors['name'][] = 'Имя может содержать только буквы, пробелы и дефис.';
        }

        if (!$this->validateRequired($data['email'])) {
            $errors['email'][] = 'Введите email.';
        } elseif (!$this->validateLength($data['email'], 5, 100)) {
            $errors['email'][] = 'Email должен содержать от 5 до 100 символов.';
        } elseif (!$this->validateEmail($data['email'])) {
            $errors['email'][] = 'Введите корректный email.';
        }

        if (!$this->validateRequired($data['password'])) {
            $errors['password'][] = 'Введите пароль.';
        } elseif (!$this->validateLength($data['password'], 8, 72)) { // bcrypt учитывает только первые 72 байта
            $errors['password'][] = 'Пароль должен содержать от 8 до 72 символов.';
        } elseif (!$this->validatePasswordStrength($data['password'])) {
            $errors['password'][] = 'Пароль должен содержать хотя бы одну букву и одну цифру.';
        }

        if (!$this->validateRequired($data['password_confirm'])) {
            $errors['password_confirm'][] = 'Повторите пароль.';
        } elseif ($data['password'] !== $data['password_confirm']) {
            $errors['password_confirm'][] = 'Пароли не совпадают.';
        }

        return $errors;
    }

    /**
     * Проверяет данные формы входа (что поля заполнены и email корректен).
     *
     * @param array $data Данные формы: email, password
     * @return array Массив ошибок для каждого поля. Если ошибок нет — пустой массив.
     */
    public function validateLogin(array $data): array
    {
        $errors = [];

        if (!$this->validateRequired($data['email'])) {
            $errors['email'][] = 'Введите email.';
        } elseif (!$this->validateEmail($data['email'])) {
            $errors['email'][] = 'Введите корректный email.';
        }

        if (!$this->validateRequired($data['password'])) {
            $errors['password'][] = 'Введите пароль.';
        }

        return $errors;
    }

    /**
     * Проверяет все данные формы заказа.
     *
     * @param array $data Данные формы: cake_id, filling_id, decor, inscription, pickup_date, comment
     * @param array $options Допустимые значения: cake_ids, filling_ids, decor_codes, date_min, date_max
     * @return array Массив ошибок для каждого поля. Если ошибок нет — пустой массив.
     */
    public function validateOrder(array $data, array $options): array
    {
        $errors = [];

        if (!$this->validateRequired($data['cake_id'])) {
            $errors['cake_id'][] = 'Выберите торт.';
        } elseif (!$this->validateInList($data['cake_id'], $options['cake_ids'])) {
            $errors['cake_id'][] = 'Выберите торт из списка.';
        }

        if (!$this->validateRequired($data['filling_id'])) {
            $errors['filling_id'][] = 'Выберите начинку.';
        } elseif (!$this->validateInList($data['filling_id'], $options['filling_ids'])) {
            $errors['filling_id'][] = 'Выберите начинку из списка.';
        }

        if (!$this->validateRequired($data['decor'])) {
            $errors['decor'][] = 'Выберите вид декора.';
        } elseif (!$this->validateInList($data['decor'], $options['decor_codes'])) {
            $errors['decor'][] = 'Выберите допустимый вид декора.';
        }

        if ($data['inscription'] !== '' && !$this->validateLength($data['inscription'], 1, 40)) { // надпись необязательна
            $errors['inscription'][] = 'Надпись не должна быть длиннее 40 символов.';
        }

        if (!$this->validateRequired($data['pickup_date'])) {
            $errors['pickup_date'][] = 'Выберите дату получения.';
        } elseif (!$this->validateDate($data['pickup_date'])) {
            $errors['pickup_date'][] = 'Введите дату в формате YYYY-MM-DD.';
        } elseif (!$this->validateDateRange($data['pickup_date'], $options['date_min'], $options['date_max'])) {
            $min = (new DateTime($options['date_min']))->format('d.m.Y');
            $max = (new DateTime($options['date_max']))->format('d.m.Y');
            $errors['pickup_date'][] = 'Выберите дату с ' . $min . ' по ' . $max . '.';
        }

        if (!$this->validateLength($data['comment'], 0, 300)) {
            $errors['comment'][] = 'Пожелания не должны быть длиннее 300 символов.';
        }

        return $errors;
    }

    /**
     * Проверяет параметры поиска по каталогу.
     *
     * @param array $data Параметры: q, flavor, price_min, price_max
     * @param array $flavors Допустимые вкусы (из БД)
     * @return array Массив ошибок для каждого поля. Если ошибок нет — пустой массив.
     */
    public function validateSearch(array $data, array $flavors): array
    {
        $errors = [];

        if (!$this->validateLength($data['q'], 0, 50)) {
            $errors['q'][] = 'Название для поиска не должно быть длиннее 50 символов.';
        }

        if ($data['flavor'] !== '' && !$this->validateInList($data['flavor'], $flavors)) {
            $errors['flavor'][] = 'Выберите вкус из списка.';
        }

        foreach (['price_min' => 'Минимальная цена', 'price_max' => 'Максимальная цена'] as $field => $label) {//поверка ввода диапазона
            if ($data[$field] !== '' && !$this->validateIntRange($data[$field], 0, 1000000)) {
                $errors[$field][] = $label . ' должна быть целым числом от 0 до 1000000.';
            }
        }

        if (
            !isset($errors['price_min']) && !isset($errors['price_max'])//сущ ли эл-т массива; если ошибки по такому ключ нет
            && $data['price_min'] !== '' && $data['price_max'] !== ''//и диапазоны не пустые
            && (int) $data['price_min'] > (int) $data['price_max']
        ) {
            $errors['price_max'][] = 'Максимальная цена не может быть меньше минимальной.';
        }

        return $errors;
    }

    public function validateCake(array $data): array{
    $errors = [];

    if (!$this->validateRequired($data['title'])) {
        $errors['title'][] = 'Введите название торта.';
    } elseif (!$this->validateLength($data['title'], 3, 50)) {
        $errors['title'][] = 'Название должно содержать от 3 до 50 символов.';
    }

    if (!$this->validateRequired($data['flavor'])) {
        $errors['flavor'][] = 'Введите вкус.';
    } elseif (!$this->validateLength($data['flavor'], 2, 50)) {
        $errors['flavor'][] = 'Вкус должен содержать от 2 до 50 символов.';
    }

    if (!$this->validateRequired($data['description'])) {
        $errors['description'][] = 'Введите описание.';
    } elseif (!$this->validateLength($data['description'], 10, 500)) {
        $errors['description'][] = 'Описание должно содержать от 10 до 500 символов.';
    }

    if (!$this->validateRequired($data['price'])) {
        $errors['price'][] = 'Введите цену.';
    } elseif (!$this->validateIntRange($data['price'], 1, 100000)) {
        $errors['price'][] = 'Цена должна быть целым числом от 1 до 100000.';
    }

    return $errors;
    }
}