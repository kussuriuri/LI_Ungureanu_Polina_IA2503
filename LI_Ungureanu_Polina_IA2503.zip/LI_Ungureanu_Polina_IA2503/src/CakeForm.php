<?php

/**
 * для админа: Принимает данные формы торта (добавление и редактирование) и проверяет их.
 */
class CakeForm
{
    private Validator $validator;

    /** @var array Ошибки валидации: ключ - имя поля, значение - список сообщений */
    public array $errors = [];

    /** @var array Данные формы (по умолчанию пустые, чтобы форма всегда могла их вывести) */
    public array $data = [
        'title' => '',
        'flavor' => '',
        'description' => '',
        'price' => '',
        'is_available' => true,
    ];

    /**
     * @param Validator $validator Объект для проверки данных
     */
    public function __construct(Validator $validator)
    {
        $this->validator = $validator;
    }

    /**
     * Читает данные из $_POST и проверяет их.
     *
     * @return bool true, если форма отправлена и данные корректны
     */
    public function handle(): bool
    {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {//потому что изм данные
            return false;
        }

        foreach (['title', 'flavor', 'description', 'price'] as $field) {
            $value = $_POST[$field] ?? null;

            if ($value !== null && !is_string($value)) {
                $this->errors[$field][] = 'Ожидается одно строковое значение.';
            }
        }

        $isAvailable = $_POST['is_available'] ?? null; // чекбокс: если не отмечен, поля в $_POST нет

        if ($isAvailable !== null && $isAvailable !== '1') {
            $this->errors['is_available'][] = 'Недопустимое значение.';
        }

        if ($this->errors !== []) {
            return false;
        }

        $this->data = [
            'title' => trim($_POST['title'] ?? ''),
            'flavor' => mb_strtolower(trim($_POST['flavor'] ?? ''), 'UTF-8'), // вкусы храним в нижнем регистре
            'description' => trim($_POST['description'] ?? ''),
            'price' => trim($_POST['price'] ?? ''),
            'is_available' => $isAvailable === '1',
        ];

        if ($this->errors !== []) {
            return false;
        }

        $this->data['price'] = (int) $this->data['price'];
        $this->errors = $this->validator->validateCake($this->data);

        return true;
    }
}