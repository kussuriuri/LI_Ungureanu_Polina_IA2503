<?php

/**
 * Принимает данные формы заказа и проверяет их.
 */
class OrderForm
{
    private Validator $validator;

    /** @var array Ошибки валидации: ключ - имя поля, значение - список сообщений */
    public array $errors = [];

    /** @var array Данные формы (по умолчанию пустые, чтобы форма всегда могла их вывести) */
    public array $data = [
        'cake_id' => '',
        'filling_id' => '',
        'decor' => '',
        'inscription' => '',
        'pickup_date' => '',
        'comment' => '',
        'gift_box' => false,
    ];

    /**
     * @param Validator $validator Объект для проверки данных
     */
    public function __construct(Validator $validator)
    {
        $this->validator = $validator;
    }

    /**
     * Читает данные из $_POST и проверяет их.
     *
     * @param array $options Допустимые значения: cake_ids, filling_ids, decor_codes, date_min, date_max
     * @return bool true, если форма отправлена и данные корректны
     */
    public function handle(array $options): bool
    {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            return false;
        }

        foreach (['cake_id', 'filling_id', 'decor', 'inscription', 'pickup_date', 'comment'] as $field) {
            $value = $_POST[$field] ?? null; // каждое поле - одна строка

            if ($value !== null && !is_string($value)) {
                $this->errors[$field][] = 'Ожидается одно строковое значение.';
            }
        }

        $giftBox = $_POST['gift_box'] ?? null; // чекбокс: если не отмечен, поля в $_POST просто нет

        if ($giftBox !== null && $giftBox !== '1') {
            $this->errors['gift_box'][] = 'Недопустимое значение.';
        }

        if ($this->errors !== []) {
            return false;
        }

        $this->data = [
            'cake_id' => trim($_POST['cake_id'] ?? ''),
            'filling_id' => trim($_POST['filling_id'] ?? ''),
            'decor' => trim($_POST['decor'] ?? ''),
            'inscription' => trim($_POST['inscription'] ?? ''),
            'pickup_date' => trim($_POST['pickup_date'] ?? ''),
            'comment' => trim($_POST['comment'] ?? ''),
            'gift_box' => $giftBox === '1',
        ];

        $this->errors = $this->validator->validateOrder($this->data, $options);

        if ($this->errors !== []) {
            return false;
        }

        $this->data['cake_id'] = (int) $this->data['cake_id'];
        $this->data['filling_id'] = (int) $this->data['filling_id'];

        return true;
    }
}