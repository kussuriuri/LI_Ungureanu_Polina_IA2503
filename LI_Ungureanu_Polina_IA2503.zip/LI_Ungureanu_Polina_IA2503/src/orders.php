<?php

/**
 * функции работы с заказами
 */

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/cakes.php';

/**
 * Возвращает варианты декора.
 *
 * @return array Ключ - код декора, значение - название для вывода
 */
function getDecors(): array{
    return [
        'minimal' => 'Минимализм',
        'flowers' => 'Цветы',
        'berries' => 'Ягоды',
        'retro' => 'Ретро (вишенки и кружево)',
    ];
}

/**
 * Возвращает статусы заказа.
 *
 * @return array Ключ - код статуса, значение - название для вывода
 */
function getOrderStatuses(): array{
    return [
        'new' => 'Новый',
        'in_progress' => 'Готовится',
        'ready' => 'Готов',
        'done' => 'Выдан',
        'cancelled' => 'Отменён',
    ];
}

/**
 * Возвращает стоимость подарочной упаковки.
 *
 * @return int Цена в леях
 */
function getGiftBoxPrice(): int{
    return 100;
}

/**
 * Возвращает допустимый диапазон дат получения: от 2 до 60 дней от сегодняшнего дня.
 *
 * @return array Массив с ключами min и max (формат YYYY-MM-DD)
 */
function getPickupDateRange(): array{//допустимый диапазон дат
    return [
        'min' => (new DateTimeImmutable('today +2 days'))->format('Y-m-d'), // Immutable - нельзя изм на месте
        'max' => (new DateTimeImmutable('today +30 days'))->format('Y-m-d'),
    ];
}

/**
 * Считает итоговую стоимость заказа: торт + доплата за начинку + упаковка.
 *
 * @param int $cakeId ID торта
 * @param int $fillingId ID начинки
 * @param bool $giftBox Нужна ли подарочная упаковка
 * @return int Итоговая цена
 */
function calculateOrderPrice(int $cakeId, int $fillingId, bool $giftBox): int{
    $cake = getCakeById($cakeId);
    $filling = getFillingById($fillingId);

    $total = (int) $cake['price'] + (int) $filling['extra_price'];

    if ($giftBox) {
        $total += getGiftBoxPrice();
    }

    return $total;
}

/**
 * Добавляет новый заказ.
 *
 * @param int $userId ID пользователя
 * @param array $data Данные заказа: cake_id, filling_id, decor, inscription, pickup_date, comment, gift_box (bool)
 * @return void
 */
function createOrder(int $userId, array $data): void{
    $sql = 'INSERT INTO orders (user_id, cake_id, filling_id, decor, inscription,
                                pickup_date, comment, gift_box, total_price)
            VALUES (:user_id, :cake_id, :filling_id, :decor, :inscription,
                    :pickup_date, :comment, :gift_box, :total_price)';

    $stmt = getPdo()->prepare($sql);
    $stmt->execute([
        'user_id' => $userId,
        'cake_id' => $data['cake_id'],
        'filling_id' => $data['filling_id'],
        'decor' => $data['decor'],
        'inscription' => $data['inscription'],
        'pickup_date' => $data['pickup_date'],
        'comment' => $data['comment'],
        'gift_box' => $data['gift_box'] ? 1 : 0, // PostgreSQL не принимает пустую строку вместо false, поэтому 1/0
        'total_price' => calculateOrderPrice($data['cake_id'], $data['filling_id'], $data['gift_box']),
    ]);
}

/**
 * Возвращает заказы одного пользователя, новые сверху.
 *
 * @param int $userId ID пользователя
 * @return array Массив заказов с названием торта (cake_title) и начинки (filling_name)
 */
function getOrdersByUser(int $userId): array{
    $sql = 'SELECT orders.*, cakes.title AS cake_title, cakes.image AS cake_image, fillings.name AS filling_name
            FROM orders
            JOIN cakes ON cakes.id = orders.cake_id
            JOIN fillings ON fillings.id = orders.filling_id
            WHERE orders.user_id = :user_id
            ORDER BY orders.created_at DESC';

    $stmt = getPdo()->prepare($sql);
    $stmt->execute(['user_id' => $userId]);

    return $stmt->fetchAll();
}

/**
 * Возвращает все заказы всех клиентов (для администратора), новые сверху.
 *
 * @return array Массив заказов с именем и email клиента, названием торта и начинки
 */
function getAllOrders(): array{
    $sql = 'SELECT orders.*, users.name AS user_name, users.email AS user_email,
                   cakes.title AS cake_title, fillings.name AS filling_name
            FROM orders
            JOIN users ON users.id = orders.user_id
            JOIN cakes ON cakes.id = orders.cake_id
            JOIN fillings ON fillings.id = orders.filling_id
            ORDER BY orders.created_at DESC';

    return getPdo()->query($sql)->fetchAll();
}

/**
 * Меняет статус заказа.
 *
 * @param int $id ID заказа
 * @param string $status Новый статус (ключ из getOrderStatuses)
 * @return void
 */
function updateOrderStatus(int $id, string $status): void{
    $stmt = getPdo()->prepare('UPDATE orders SET status = :status WHERE id = :id');
    $stmt->execute(['id' => $id, 'status' => $status]);
}