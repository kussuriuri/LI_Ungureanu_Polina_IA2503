<?php

//регистр польза на ур БД -вход, выход, сессии и определение текущего пользователя

/**
 * аутентификация: пользователи в БД, сессии, проверка роли
 */

require_once __DIR__ . '/functions.php';

/**
 * Запускает сессию с безопасными параметрами cookie (один раз за запрос).
 *
 * @return void
 */
function startSession(): void //запуск сессии с опр парам-и безопасности
{
    if (session_status() === PHP_SESSION_ACTIVE) { //session_status() - встр ф - сообщ текущ сост сесии; PHP_SESSION_ACTIVE - конст - сессия запущена
        return;
    }

    session_set_cookie_params([ //встр ф - задает парам-ы cookie - исп для идентифик сессии
        'httponly' => true,   //запрещает обычному JavaScript в браузере читать эту cookie через document.cookie
        'samesite' => 'Lax',  //ограничивает отправку cookie при межсайтовых запросах
    ]);

    session_start();//запуск нов/ продолж текущ если браузер передал коррект индентифик сессии
}

/**
 * Ищет пользователя по email.
 *
 * @param string $email Email пользователя
 * @return array|null Данные пользователя или null, если такого нет
 */
function findUserByEmail(string $email): ?array //поиск польз-а по email в БД
{
    $stmt = getPdo()->prepare('SELECT * FROM users WHERE email = :email');//у получ подкл выз метод подготовки sql- запроса
    $stmt->execute(['email' => $email]);//ключ массива соотв введенному - перед отдельно от запроса

    $user = $stmt->fetch();//получ 1 строку рез-а запроса 

    if ($user === false) {
        return null;
    }

    return $user;
}

/**
 * Ищет пользователя по ID.
 *
 * @param int $id ID пользователя
 * @return array|null Данные пользователя или null, если такого нет
 */
function findUserById(int $id): ?array
{
    $stmt = getPdo()->prepare('SELECT * FROM users WHERE id = :id');
    $stmt->execute(['id' => $id]);

    $user = $stmt->fetch();

    if ($user === false) {
        return null;
    }

    return $user;
}

/**
 * Создает нового пользователя. Пароль сохраняется только в виде хеша.
 *
 * @param array $data Данные пользователя: name, email, password
 * @param string $role Роль: client (по умолчанию) или admin
 * @return void
 */
function createUser(array $data, string $role = 'client'): void //добав нов польз-а в БД
{
    $sql = 'INSERT INTO users (name, email, password_hash, role)
            VALUES (:name, :email, :password_hash, :role)';

    $stmt = getPdo()->prepare($sql);
    $stmt->execute([ //передача знач
        'name' => $data['name'],
        'email' => $data['email'],
        'password_hash' => password_hash($data['password'], PASSWORD_DEFAULT), //PASSWORD_DEFAULT - рек алго по ум; случ хэш
        'role' => $role,
    ]);
}

/**
 * Проверяет email и пароль. При успехе пользователь "входит" в систему.
 *
 * @param string $email Введённый email
 * @param string $password Введённый пароль
 * @return bool true, если вход выполнен
 */
function loginUser(string $email, string $password): bool
{
    $user = findUserByEmail($email);

    if ($user === null || !password_verify($password, $user['password_hash'])) {// password_verify сравнивает пароль с хешем из БД
        return false;
    }

    startSession();
    session_regenerate_id(true); // созд новый ID сессии; true - стар будет удален (защита от фиксации сессии)
    $_SESSION['user_id'] = (int) $user['id'];//сохо id польз-а; $_SESSION - суперглобал массив сессии; ['user_id'] — ключ, под которым сохраняется ID; $user['id'] - ID пользователя из базы данных;
    return true;
}

/**
 * Завершает сессию пользователя.
 *
 * @return void
 */
function logoutUser(): void
{
    startSession();

    $_SESSION = []; // удаление данных сессии
    session_destroy(); // уничтожение сессии
}

/**
 * Возвращает текущего вошедшего пользователя.
 * Данные берутся из БД, а в сессии хранится только ID.
 *
 * @return array|null Данные пользователя или null, если гость
 */
function getCurrentUser(): ?array
{
    startSession();

    $id = $_SESSION['user_id'] ?? null;//id польз-а текущ сессии

    if (!is_int($id)) {//если null
        return null;
    }

    return findUserById($id);//ищем этого польз-а в БД
}

/**
 * Проверяет, является ли текущий пользователь администратором.
 *
 * @return bool true, если пользователь вошёл и его роль admin
 */
function isAdmin(): bool
{
    $user = getCurrentUser();

    return $user !== null && $user['role'] === 'admin';
}