<?php

/**
 * общие функции: подключение к БД, экранирование, вывод ошибок, чтение параметров запроса
 */

require_once __DIR__ . '/Database.php';//единожды подкл др файл; __DIR__ - конст, содерж путь к папке с текущ файлом; 

date_default_timezone_set('Europe/Chisinau'); //час пояс для раб с датами по ум

/**
 * Возвращает соединение с базой данных. Подключение создается один раз.
 *
 * @return PDO Объект соединения
 */
function getPdo(): PDO
{
    static $pdo = null; // static - значение сохр между вызовами функции в рамках 1-го запроса

    if ($pdo === null) {//если подкл нет - созд его
        $config = require __DIR__ . '/../config.php';
        $database = new Database($config);
        $pdo = $database->getConnection();//подключение сохр в статич перем
    }

    return $pdo;
}

/**
 * Экранирует текст для безопасного вывода в HTML (защита от XSS).
 *
 * @param string $value Исходный текст
 * @return string Безопасный текст
 */
function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');//преобр спец-символы в html сущности (& = &amp;) -> браузер отображ символы как текс; ENT_SUBSTITUTE = неккорект послед символов замен символами замены
}

/**
 * Выводит список ошибок для одного поля формы.
 *
 * @param array $errors Ошибки: ключ - имя поля, значение - список сообщений
 * @param string $field Имя поля
 * @return void
 */
function getErrors(array $errors, string $field): void //выв список ошибок для поля
{
    $fieldErrors = $errors[$field] ?? [];

    if ($fieldErrors === []) {
        return;
    }

    echo '<ul class="errors">';//css класс оформ список ошибок стилями

    foreach ($fieldErrors as $error) {
        echo '<li>' . h($error) . '</li>';//экранируем ошибку текстом
    }

    echo '</ul>';
}

/**
 * Преобразует дату из формата БД (YYYY-MM-DD) в формат для вывода (ДД.ММ.ГГГГ).
 *
 * @param string $date Дата или дата со временем из БД
 * @return string Дата в формате d.m.Y
 */
function formatDate(string $date): string
{
    return date('d.m.Y', strtotime($date));//strtotime - преобр текст представ даты в числовое представ
}

/**
 * Безопасно читает строковое значение из $_POST.
 *
 * @param string $key Имя поля
 * @return string Значение или пустая строка, если поля нет или оно не строка
 */
function getPostString(string $key): string//получ строк знач из массива POST (содерж данные, отправленные браузером серв-у)
{
    $value = $_POST[$key] ?? '';

    return is_string($value) ? $value : ''; // злоумышленник может отправить массив вместо строки
}

/**
 * Безопасно читает строковое значение из $_GET.
 *
 * @param string $key Имя параметра
 * @return string Значение или пустая строка, если параметра нет или он не строка
 */
function getQueryString(string $key): string//GET - содерж парам-ы, переданные в URL
{
    $value = $_GET[$key] ?? '';

    return is_string($value) ? $value : '';
}

/**
 * Возвращает адрес картинки торта для вывода на странице.
 *
 * @param string $image Имя файла из БД (может быть пустым)
 * @return string|null Адрес картинки или null, если картинки нет или файл не найден
 */
function getCakeImageUrl(string $image): ?string 
{
    $name = basename($image); // basename отсекает любые пути, остаётся только имя файла - cake.jpg

    if ($name === '' || !is_file(__DIR__ . '/../public/images/' . $name)) {
        return null;
    }

    return 'images/' . $name;//возвр адрес по кот браузер сможет загруз ее
}