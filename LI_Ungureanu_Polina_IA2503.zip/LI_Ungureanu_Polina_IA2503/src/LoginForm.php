<?php

/**
 * Принимает данные формы входа и проверяет их.
 */
class LoginForm
{
    private Validator $validator;

    /** @var array Ошибки валидации: ключ - имя поля, значение - список сообщений */
    public array $errors = [];

    /** @var array Данные формы */
    public array $data = [
        'email' => '',
        'password' => '',
    ];

    /**
     * @param Validator $validator Объект для проверки данных
     */
    public function __construct(Validator $validator)
    {
        $this->validator = $validator; //исп общ механизм валидации
    }

    /**
     * Читает данные из $_POST и проверяет их.
     *
     * @return bool true, если форма отправлена и данные корректны
     */
    public function handle(): bool
    {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            return false;
        }

        foreach (['email', 'password'] as $field) {//проверяется корректность ввода
            $value = $_POST[$field] ?? null;

            if ($value !== null && !is_string($value)) {//корректность типа
                $this->errors[$field][] = 'Ожидается одно строковое значение.';
            }
        }

        if ($this->errors !== []) {
            return false;
        }

        $this->data = [
            'email' => mb_strtolower(trim($_POST['email'] ?? ''), 'UTF-8'),
            'password' => $_POST['password'] ?? '',
        ];

        $this->errors = $this->validator->validateLogin($this->data);//проверяются данные

        return $this->errors === [];
    }
}