<?php

/**
 * обработчики действий пользователя и администратора и созд;
 */

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/cakes.php';
require_once __DIR__ . '/orders.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/Validator.php';
require_once __DIR__ . '/RegisterForm.php';
require_once __DIR__ . '/LoginForm.php';
require_once __DIR__ . '/OrderForm.php';
require_once __DIR__ . '/CakeForm.php';
require_once __DIR__ . '/SearchForm.php';

/**
 * Регистрация: если форма отправлена и корректна, создаёт пользователя.
 *
 * @param RegisterForm $form Объект формы
 * @return void
 */
function handleRegister(RegisterForm $form): void//проверяет можно ли созд польз-а; передаем форму(метод handle, data с введенными данными, errors)
{
    if (!$form->handle()) {//если обработка не успешна
        return;
    }

    if (findUserByEmail($form->data['email']) !== null) { //если находим польз-а с таким же email
        $form->errors['email'][] = 'Пользователь с таким email уже зарегистрирован.';
        return;
    }

    createUser($form->data);//создаем польз-а с парам-ами введенными в форме; форма была отправлена - данные прошли проверку - польз с таким email еще не зареган

    header('Location: login.php?registered=1');//отправка http-заголовка браузеру; перенаправ на стр входа
    exit;//останав выполн текущ скрипта
}

/**
 * Вход: если форма отправлена и корректна, проверяет email и пароль.
 *
 * @param LoginForm $form Объект формы
 * @return void
 */
function handleLogin(LoginForm $form): void
{
    if (!$form->handle()) {//была ли форма отправ и прошли ли данные валидацию
        return;
    }

    if (!loginUser($form->data['email'], $form->data['password'])) {//сущ ли польз с такой почтой и соотв ли пароль хэшу из БД
        $form->errors['password'][] = 'Неверный email или пароль.';
        return;
    }

    header('Location: index.php');//на главную
    exit;
}

/**
 * Выход: срабатывает только на POST-запрос с action=logout.
 *
 * @return void
 */
function handleLogout(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || ($_POST['action'] ?? '') !== 'logout') {//выполн только если это logout ч/з POST
        return;
    }

    logoutUser();

    header('Location: index.php');
    exit;
}

/**
 * Не пускает уже вошедшего пользователя на страницы входа и регистрации.
 *
 * @return void
 */
function redirectIfLoggedIn(): void
{
    if (getCurrentUser() !== null) {//если текущ польз не гость(польз)
        header('Location: index.php');//перенапрв на главн стр
        exit;
    }
}

/**
 * Пускает на страницу только вошедших пользователей, гостя отправляет на вход.
 *
 * @return array Данные текущего пользователя
 */
function requireLogin(): array
{
    $user = getCurrentUser();//данные текущ польз-а

    if ($user === null) {
        header('Location: login.php');
        exit;
    }

    return $user;//возвр данные
}

/**
 * Пускает на страницу только администратора.
 * Гостя отправляет на вход, а вошедшему клиенту показывает ошибку 403.
 *
 * @return array Данные текущего пользователя (администратора)
 */
function requireAdmin(): array
{
    $user = requireLogin();//провер есть ли такой польз и возвр его данные

    if ($user['role'] !== 'admin') {
        http_response_code(403); // уст http код ответа: 403 - доступ запрещён
        echo 'Доступ запрещён.';
        exit;
    }

    return $user;
}

/**
 * Создание заказа: если форма отправлена и корректна, добавляет запись.
 *
 * @param OrderForm $form Объект формы
 * @param int $userId ID пользователя, оформляющего заказ
 * @return void
 */
function handleCreateOrder(OrderForm $form, int $userId): void//приним об формы заказа и id польз-а этого заказа
{
    $options = [ // допустимые значения берём из БД и из настроек
        'cake_ids' => getAvailableCakeIds(),
        'filling_ids' => getFillingIds(),
        'decor_codes' => array_keys(getDecors()),
        'date_min' => getPickupDateRange()['min'],
        'date_max' => getPickupDateRange()['max'],
    ];

    if ($form->handle($options)) {
        createOrder($userId, $form->data);
        header('Location: my_orders.php?success=1');
        exit;
    }
}

/**
 * Создание торта: если форма отправлена и корректна, добавляет запись.
 *
 * @param CakeForm $form Объект формы
 * @return void
 */
function handleCreateCake(CakeForm $form): void
{
    if ($form->handle()) {
        createCake($form->data);
        header('Location: admin_cakes.php?success=created');
        exit;
    }
}

/**
 * Обновление торта: если форма отправлена и корректна, обновляет запись.
 *
 * @param int $id ID торта
 * @param CakeForm $form Объект формы
 * @return void
 */
function handleUpdateCake(int $id, CakeForm $form): void
{
    if ($form->handle()) {
        updateCake($id, $form->data);
        header('Location: admin_cakes.php?success=updated');
        exit;
    }
}

/**
 * Удаление торта: срабатывает только на POST-запрос с action=delete.
 * Торт, на который есть заказы, не удаляется - его нужно снять с продажи.
 *
 * @return void
 */
function handleDeleteCake(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || getPostString('action') !== 'delete') {
        return;
    }

    $id = filter_var(getPostString('delete_id'), FILTER_VALIDATE_INT);

    if ($id === false) {
        header('Location: admin_cakes.php');
        exit;
    }

    if (cakeHasOrders($id)) {
        header('Location: admin_cakes.php?error=has_orders');
        exit;
    }

    deleteCake($id);
    header('Location: admin_cakes.php?success=deleted');
    exit;
}

/**
 * Создание нового администратора: если форма отправлена и корректна, добавляет пользователя с ролью admin.
 *
 * @param RegisterForm $form Объект формы
 * @return void
 */
function handleCreateAdmin(RegisterForm $form): void
{
    if (!$form->handle()) {
        return;
    }

    if (findUserByEmail($form->data['email']) !== null) {
        $form->errors['email'][] = 'Пользователь с таким email уже зарегистрирован.';
        return;
    }

    createUser($form->data, 'admin');

    header('Location: admin_users.php?success=admin_created');
    exit;
}

/**
 * Смена статуса заказа: срабатывает только на POST-запрос с action=set_status.
 *
 * @return void
 */
function handleUpdateOrderStatus(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || getPostString('action') !== 'set_status') {
        return;
    }

    $id = filter_var(getPostString('order_id'), FILTER_VALIDATE_INT);
    $status = getPostString('status');

    if ($id !== false && array_key_exists($status, getOrderStatuses())) { // статус должен быть из списка
        updateOrderStatus($id, $status);
    }

    header('Location: admin_orders.php');
    exit;
}

/**
 * Действия над пользователями: смена роли (action=set_role) и удаление (action=delete).
 * Свою учётную запись менять и удалять нельзя.
 *
 * @param int $currentUserId ID администратора, который выполняет действие
 * @return void
 */
function handleUserActions(int $currentUserId): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        return;
    }

    $action = getPostString('action');

    if ($action !== 'set_role' && $action !== 'delete') {
        return;
    }

    $id = filter_var(getPostString('user_id'), FILTER_VALIDATE_INT);

    if ($id === false) {
        header('Location: admin_users.php');
        exit;
    }

    if ($id === $currentUserId) {
        header('Location: admin_users.php?error=self');
        exit;
    }

    if ($action === 'set_role') {
        $role = getPostString('role');

        if (in_array($role, getRoles(), true)) {
            updateUserRole($id, $role);
        }

        header('Location: admin_users.php?success=role');
        exit;
    }

    deleteUser($id);
    header('Location: admin_users.php?success=deleted');
    exit;
}