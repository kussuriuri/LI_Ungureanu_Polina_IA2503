<?php

/**
 * Принимает данные формы регистрации и проверяет их
 */
class RegisterForm{

    private Validator $validator;//об класса Validator(содерж правила проверки email)

    /** @var array Ошибки валидации: ключ - имя поля, значение - список сообщений */
    public array $errors = [];//хран ошибки проверк формы

    /** @var array Данные формы (по умолчанию пустые, чтобы форма всегда могла их вывести) */
    public array $data = [ //Если пользователь отправил форму с ошибкой, приложение может сохранить введённые значения и повторно показать их в форме
        'name' => '',
        'email' => '',
        'password' => '',
        'password_confirm' => '',
    ];

    /**
     * @param Validator $validator Объект для проверки данных
     */
    public function __construct(Validator $validator)
    {
        $this->validator = $validator;//переданный об передается в об этого класса
    }

    /**
     * Читает данные из $_POST и проверяет их.
     *
     * @return bool true, если форма отправлена и данные корректны
     */
    public function handle(): bool
    {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {//нужен POST
            return false;
        }

        foreach (['name', 'email', 'password', 'password_confirm'] as $field) { // каждое поле - одна строка
            $value = $_POST[$field] ?? null;//получ знач поля из POST

            if ($value !== null && !is_string($value)) {
                $this->errors[$field][] = 'Ожидается одно строковое значение.';
            }
        }

        if ($this->errors !== []) {//если есть ошибки
            return false;
        }

        $this->data = [//массив данных ввденных польз-ем
            'name' => trim($_POST['name'] ?? ''),
            'email' => mb_strtolower(trim($_POST['email'] ?? ''), 'UTF-8'), // email храним в нижнем регистре
            'password' => $_POST['password'] ?? '', // пароль НЕ обрезаем: пробелы могут быть его частью
            'password_confirm' => $_POST['password_confirm'] ?? '',
        ];

        $this->errors = $this->validator->validateRegister($this->data);//вызов метода проверки регистрации (с массивом уже подготов данных) у валидатора (возвр массив ошибок)

        return $this->errors === [];//true когда форма отправлена POST, все получ знач имеют ожидаемые типы, проверка валидатор не нашла ошибок
    }
}