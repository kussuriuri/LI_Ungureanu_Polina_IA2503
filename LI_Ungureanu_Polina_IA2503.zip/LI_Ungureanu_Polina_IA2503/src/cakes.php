<?php

/**
 * функции работы с тортами и начинками
 */

require_once __DIR__ . '/functions.php';

/**
 * Возвращает все торты (для каталога и админ-панели).
 *
 * @return array Массив тортов
 */
function getAllCakes(): array
{
    return getPdo()->query('SELECT * FROM cakes ORDER BY title')->fetchAll();
}

/**
 * Возвращает торты, доступные для заказа.
 *
 * @return array Массив тортов
 */
function getAvailableCakes(): array
{
    return getPdo()->query('SELECT * FROM cakes WHERE is_available = TRUE ORDER BY title')->fetchAll();
}

/**
 * Возвращает id доступных тортов в виде строк (для проверки формы).
 *
 * @return array Массив строк, например ['1', '2']
 */
function getAvailableCakeIds(): array
{
    $ids = [];

    foreach (getAvailableCakes() as $cake) {
        $ids[] = (string) $cake['id']; // данные из html приходят в php как строки
    }

    return $ids;
}

/**
 * Возвращает новинки - последние добавленные торты.
 *
 * @param int $limit Сколько тортов вернуть
 * @return array Массив тортов
 */
function getNewCakes(int $limit = 3): array
{
    $sql = 'SELECT * FROM cakes
            WHERE is_available = TRUE
            ORDER BY created_at DESC, id DESC
            LIMIT ' . (int) $limit; // LIMIT подставляем как число, приведённое к int

    return getPdo()->query($sql)->fetchAll();
}

/**
 * Возвращает один торт по ID.
 *
 * @param int $id ID торта
 * @return array|null Данные торта или null, если такого нет
 */
function getCakeById(int $id): ?array
{
    $stmt = getPdo()->prepare('SELECT * FROM cakes WHERE id = :id');
    $stmt->execute(['id' => $id]);

    $cake = $stmt->fetch();

    if ($cake === false) {
        return null;
    }

    return $cake;
}

/**
 * Возвращает список вкусов, которые есть в каталоге (для выпадающего списка поиска).
 *
 * @return array Массив строк, например ['ваниль', 'шоколад']
 */
function getFlavors(): array
{
    return getPdo()->query('SELECT DISTINCT flavor FROM cakes ORDER BY flavor')->fetchAll(PDO::FETCH_COLUMN);
}

/**
 * Ищет торты по заданным критериям. Пустые критерии не учитываются.
 *
 * @param array $filters Критерии: q (часть названия), flavor, price_min, price_max, only_available (bool)
 * @return array Массив найденных тортов
 */
function searchCakes(array $filters): array
{
    $where = [];
    $params = [];

    if ($filters['q'] !== '') {
        $where[] = 'title ILIKE :q'; // ILIKE - поиск без учёта регистра
        $params['q'] = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $filters['q']) . '%'; // экранируем спецсимволы LIKE
    }

    if ($filters['flavor'] !== '') {
        $where[] = 'flavor = :flavor';
        $params['flavor'] = $filters['flavor'];
    }

    if ($filters['price_min'] !== '') {
        $where[] = 'price >= :price_min';
        $params['price_min'] = (int) $filters['price_min'];
    }

    if ($filters['price_max'] !== '') {
        $where[] = 'price <= :price_max';
        $params['price_max'] = (int) $filters['price_max'];
    }

    if ($filters['only_available']) {
        $where[] = 'is_available = TRUE';
    }

    $sql = 'SELECT * FROM cakes';

    if ($where !== []) {
        $sql .= ' WHERE ' . implode(' AND ', $where); // условия соединяются через AND
    }

    $sql .= ' ORDER BY title';

    $stmt = getPdo()->prepare($sql);
    $stmt->execute($params); // значения передаются отдельно от SQL - защита от инъекций

    return $stmt->fetchAll();
}

/**
 * Добавляет новый торт.
 *
 * @param array $data Данные торта: title, flavor, description, price, is_available (bool)
 * @return void
 */
function createCake(array $data): void
{
    $sql = 'INSERT INTO cakes (title, flavor, description, price, is_available)
            VALUES (:title, :flavor, :description, :price, :is_available)';

    $stmt = getPdo()->prepare($sql);
    $stmt->execute([
        'title' => $data['title'],
        'flavor' => $data['flavor'],
        'description' => $data['description'],
        'price' => $data['price'],
        'is_available' => $data['is_available'] ? 1 : 0,
    ]);
}

/**
 * Обновляет существующий торт.
 *
 * @param int $id ID торта
 * @param array $data Новые данные: title, flavor, description, price, is_available (bool)
 * @return void
 */
function updateCake(int $id, array $data): void
{
    $sql = 'UPDATE cakes
            SET title = :title, flavor = :flavor, description = :description,
                price = :price, is_available = :is_available
            WHERE id = :id';

    $stmt = getPdo()->prepare($sql);
    $stmt->execute([
        'id' => $id,
        'title' => $data['title'],
        'flavor' => $data['flavor'],
        'description' => $data['description'],
        'price' => $data['price'],
        'is_available' => $data['is_available'] ? 1 : 0,
    ]);
}

/**
 * Проверяет, есть ли заказы на этот торт.
 *
 * @param int $id ID торта
 * @return bool true, если хотя бы один заказ существует
 */
function cakeHasOrders(int $id): bool
{
    $stmt = getPdo()->prepare('SELECT COUNT(*) FROM orders WHERE cake_id = :id');
    $stmt->execute(['id' => $id]);

    return (int) $stmt->fetchColumn() > 0;
}

/**
 * Удаляет торт по ID.
 *
 * @param int $id ID торта
 * @return void
 */
function deleteCake(int $id): void
{
    $stmt = getPdo()->prepare('DELETE FROM cakes WHERE id = :id');
    $stmt->execute(['id' => $id]);
}

/**
 * Возвращает список всех начинок (для выпадающего списка и главной страницы).
 *
 * @return array Массив начинок: id, name, description, extra_price
 */
function getFillings(): array
{
    return getPdo()->query('SELECT * FROM fillings ORDER BY name')->fetchAll();
}

/**
 * Возвращает id всех начинок в виде строк (для проверки формы).
 *
 * @return array Массив строк
 */
function getFillingIds(): array
{
    $ids = [];

    foreach (getFillings() as $filling) {
        $ids[] = (string) $filling['id'];
    }

    return $ids;
}

/**
 * Возвращает одну начинку по ID.
 *
 * @param int $id ID начинки
 * @return array|null Данные начинки или null, если такой нет
 */
function getFillingById(int $id): ?array
{
    $stmt = getPdo()->prepare('SELECT * FROM fillings WHERE id = :id');
    $stmt->execute(['id' => $id]);

    $filling = $stmt->fetch();

    if ($filling === false) {
        return null;
    }

    return $filling;
}