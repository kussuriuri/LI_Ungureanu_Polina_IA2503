<?php

/**
 * Принимает параметры поиска по каталогу из адресной строки (GET) и проверяет их.
 */
class SearchForm
{
    private Validator $validator;

    /** @var array Ошибки валидации: ключ - имя поля, значение - список сообщений */
    public array $errors = [];

    /** @var array Параметры поиска (по умолчанию пустые - значит, показываем все торты) */
    public array $data = [
        'q' => '',
        'flavor' => '',
        'price_min' => '',
        'price_max' => '',
        'only_available' => false,
    ];

    /**
     * @param Validator $validator Объект для проверки данных
     */
    public function __construct(Validator $validator)
    {
        $this->validator = $validator;
    }

    /**
     * Читает параметры из $_GET и проверяет их.
     *
     * @param array $flavors Допустимые вкусы (из БД)
     * @return bool true, если параметры корректны
     */
    public function handle(array $flavors): bool
    {
        foreach (['q', 'flavor', 'price_min', 'price_max'] as $field) {
            $value = $_GET[$field] ?? null;

            if ($value !== null && !is_string($value)) {
                $this->errors[$field][] = 'Ожидается одно строковое значение.';
            }
        }

        $onlyAvailable = $_GET['only_available'] ?? null;

        if ($onlyAvailable !== null && $onlyAvailable !== '1') {
            $this->errors['only_available'][] = 'Недопустимое значение.';
        }

        if ($this->errors !== []) {
            return false;
        }

        $this->data = [
            'q' => trim($_GET['q'] ?? ''),
            'flavor' => trim($_GET['flavor'] ?? ''),
            'price_min' => trim($_GET['price_min'] ?? ''),
            'price_max' => trim($_GET['price_max'] ?? ''),
            'only_available' => $onlyAvailable === '1',
        ];

        $this->errors = $this->validator->validateSearch($this->data, $flavors);

        return $this->errors === [];
    }
}